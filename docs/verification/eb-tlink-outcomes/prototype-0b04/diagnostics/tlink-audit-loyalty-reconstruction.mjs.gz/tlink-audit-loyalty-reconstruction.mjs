import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import { resolve } from 'node:path';
import { hashSeed } from '../../src/content/seedHash.ts';

const source = '0b04cd0becc4d73059fbfcf372395c8672d1a381';
const directory = '.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const pins = {
  'seed-1.json': 'd582bc5a5254b9ad635c54a103304b47071b21b743a4ae77726a58a86cc4514b',
  'seed-1/original-contexts.json.gz': 'fcbaaea620523118bfdb74e82ca2bdacbc0078213aaba3007be35f16e35fafa3',
  'seed-1/original-final-state.json.gz': 'fd4c7112b31d2acb17264638bdf1a904239b241124175a74709907dcb782c03e',
};
const inputs = {};
const read = name => {
  const bytes = readFileSync(resolve(directory, name));
  assert.equal(sha(bytes), pins[name], `input pin ${name}`);
  inputs[name] = { path: resolve(directory, name), sha256: sha(bytes), bytes: bytes.length };
  return JSON.parse(name.endsWith('.gz') ? gunzipSync(bytes).toString('utf8') : bytes.toString('utf8'));
};
const sourceFiles = ['src/engine/stewardship.ts', 'src/engine/prng.ts', 'src/content/stewardshipConfig.ts', 'src/content/seedHash.ts'].map(path => {
  const pinned = execFileSync('git', ['show', `${source}:${path}`]);
  const current = readFileSync(path);
  assert.deepEqual(current, pinned, `source drift ${path}`);
  return { path, sha256: sha(pinned), bytesEqualPinned: true };
});
const raw = read('seed-1.json'), contexts = read('seed-1/original-contexts.json.gz');
const state = read('seed-1/original-final-state.json.gz');
assert.equal(raw.provenance.sourceRevision, source);
assert.equal(state.seed, 1);
assert.equal(state.tick, raw.endTick);
const { stewards, audits, nextAudit } = state.stewardship;
assert.equal(new Set(stewards.map(row => row.personId)).size, stewards.length);
assert.equal(audits.length, nextAudit - 1);
assert.deepEqual(audits.map(row => row.id), Array.from({ length: nextAudit - 1 }, (_, index) => `audit-${index + 1}`));
const explicit = contexts.filter(row => row.command.type === 'answer_audit' && row.command.choice === 'tolerate');
const byAudit = new Map(explicit.map(row => [row.command.auditId, row]));
assert.equal(byAudit.size, explicit.length);
const sequences = [], answerRows = [], counts = { explicitPositive: 0, explicitZero: 0, otherToleratedPositive: 0, otherToleratedZero: 0 };
for (const steward of stewards) {
  const peers = stewards.filter(row => row.estateId === steward.estateId);
  const index = peers.findIndex(row => row.personId === steward.personId);
  assert.equal(steward.disposition, ['merchant', 'peasant', 'greedy'][index % 3]);
  const estateNumber = Number(steward.estateId.replace(/\D+/g, '')) || 0;
  const salt = what => hashSeed(state.seed, `steward:${what}`, estateNumber, index);
  assert.equal(steward.ability, 30 + salt('ability') % 61);
  const initial = steward.disposition === 'greedy' ? 20 + salt('loyalty') % 31 : 55 + salt('loyalty') % 36;
  let loyalty = initial, previousDeadline = -1;
  const events = [];
  for (const audit of audits.filter(row => row.stewardId === steward.personId)) {
    assert.ok(audit.tick > previousDeadline, 'overlapping audits prevent settlement-order proof');
    previousDeadline = audit.deadline;
    assert.equal(audit.estateId, steward.estateId);
    const before = loyalty, command = byAudit.get(audit.id);
    if (command) {
      assert.equal(audit.status, 'tolerated');
      assert.equal(command.stateChanged, true);
      assert.ok(command.tick >= audit.tick && command.tick <= audit.deadline);
      assert.equal(command.history.params.subjectId, audit.id);
    }
    if (audit.status === 'tolerated') {
      loyalty = Math.min(100, loyalty + 10);
      counts[`${command ? 'explicit' : 'otherTolerated'}${loyalty === before ? 'Zero' : 'Positive'}`]++;
    }
    const event = { auditId: audit.id, auditTick: audit.tick, deadline: audit.deadline, status: audit.status,
      before, after: loyalty, actualDelta: loyalty - before, explicitContextOrdinal: command?.ordinal ?? null,
      answerTick: command?.tick ?? null, historyId: command?.history?.id ?? null };
    events.push(event);
    if (command) answerRows.push({ ...event, estateId: steward.estateId, stewardId: steward.personId,
      laterOwnBecause: raw.history.filter(row => row.tick > command.tick && row.because?.some(cause => cause.decisionId === command.history.id)).map(row => row.id) });
  }
  assert.equal(loyalty, steward.loyalty, `final loyalty mismatch ${steward.personId}`);
  sequences.push({ personId: steward.personId, estateId: steward.estateId, disposition: steward.disposition,
    candidateIndex: index, estateNumber, initialLoyalty: initial, observedFinalLoyalty: steward.loyalty, recomputedFinalLoyalty: loyalty, events });
}
assert.equal(answerRows.length, explicit.length);
answerRows.sort((a, b) => a.explicitContextOrdinal - b.explicitContextOrdinal);
const residualPath = process.argv[2];
let residualIntersection = null;
if (residualPath) {
  const bytes = readFileSync(residualPath), residual = JSON.parse(bytes);
  const provisional = Array.isArray(residual.auditTolerateUnlinkedIds);
  if (provisional) {
    assert.equal(residual.sourceRevision, source);
    for (const input of residual.inputs) assert.equal(sha(readFileSync(input.path)), input.sha256);
    const derived = residual.rows.filter(row => row.command === 'answer_audit' && row.source.startsWith('audit:tolerate:')
      && row.mature && row.directReceipts.length === 0).map(row => row.historyId);
    assert.deepEqual(residual.auditTolerateUnlinkedIds, derived);
  }
  const ids = new Set(provisional ? residual.auditTolerateUnlinkedIds : residual.residuals.filter(row => row.seed === 1).map(row => row.historyId));
  const matches = answerRows.filter(row => ids.has(row.historyId));
  residualIntersection = { path: resolve(residualPath), sha256: sha(bytes), inputStatus: residual.status ?? 'baseline-residual-artifact', matched: matches.length,
    positive: matches.filter(row => row.actualDelta > 0).length, zero: matches.filter(row => row.actualDelta === 0).length,
    historyIds: matches.map(row => row.historyId) };
}
const output = { schemaVersion: 1, kind: 'offline-source-derived-loyalty-reconstruction', source, inputs, sourceFiles,
  scriptSha256: sha(readFileSync(new URL(import.meta.url))), command: 'node --import tsx .omo/evidence/tlink-audit-loyalty-reconstruction.mjs [residual.json]',
  validations: { finalLoyaltyMatched: sequences.length, stewardCount: stewards.length, completeAuditSequence: audits.length,
    nonoverlappingAuditWindows: true, candidateAbilityAndDispositionMatched: true }, counts, answerRows, sequences, residualIntersection,
  sourceAnchors: ['stewardship.ts:40,59,86-108 candidate initialization', 'stewardship.ts:140,163 append-only stewards',
    'stewardship.ts:551 sole post-initialization loyalty writer', 'stewardship.ts:385-389 lapse routes through answerAudit',
    'stewardship.ts:338-343 loyalty affects rounded kept/error/reported', 'stewardshipConfig.ts:104 +10'],
  limits: ['Source-derived before/after loyalty, not archived answer-time snapshots or engine replay.',
    'Other tolerated audits may be automatic lapses or nested registry commands; these routes are not classified here.',
    'Positive loyalty does not prove changed future kept, reported income, audit detection or cause ownership.',
    'No future amount, coverage threshold, renderer acceptance or completed replay-validation claim.',
    'Residual membership only proved when an explicit residual artifact is supplied; no prefix matching.'] };
writeFileSync('.omo/evidence/tlink-audit-loyalty-reconstruction.json', JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify({ validations: output.validations, counts, residualIntersection }));
