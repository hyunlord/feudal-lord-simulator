import { readFileSync, mkdirSync, writeFileSync, openSync, closeSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawn } from 'node:child_process';
import { join } from 'node:path';
import { loadChromium, openScene } from '../../scripts/renderCommitProbe.mjs';
const out = '.remote/tlink-056-probe';
mkdirSync(out, { recursive: true });
const port = process.env.FLS_REMOTE_PORT;
if (!port) throw new Error('official remote port required');
const raw = readFileSync(join(process.env.HOME, 'fls-variant-states/home-056.json'));
const state = JSON.parse(raw);
const report = { sourceStateSha256: createHash('sha256').update(raw).digest('hex'), tick: state.tick, stages: [], errors: [] };
const log = openSync(`${out}/vite.log`, 'w');
const server = spawn(process.execPath, ['node_modules/vite/bin/vite.js', '--host', '127.0.0.1', '--port', port, '--strictPort'], { stdio: ['ignore', log, log] });
let browser;
try {
 const url = `http://127.0.0.1:${port}/`;
 let ready = false;
 for (let i=0; i<120; i++) { if (await fetch(url).then(r=>r.ok).catch(()=>false)) { ready=true; break; } await new Promise(r=>setTimeout(r,500)); }
 if (!ready) throw new Error('Vite unavailable');
 browser = await (await loadChromium()).launch({ channel: 'chrome', headless: true });
 const {page, context} = await openScene(browser, { state, tile:[45,41], baseUrl:url, width:1280,height:800, run:false, zoom:1.1, loadTimeout:120000, query:'&story-delay=3000', initScript:"globalThis.__name = globalThis.__name || (target => target); localStorage.setItem('feudal-lord-simulator:tutorial:v1', JSON.stringify({enabled:false,acks:[],pulsed:[],log:[]}));" });
 page.on('pageerror', e=>report.errors.push(String(e)));
 const snapshot = async label => report.stages.push({label, dom:await page.evaluate(()=>({ chips:[...document.querySelectorAll('.event-chip')].map(e=>({story:e.getAttribute('data-story'),text:e.textContent})), cards:[...document.querySelectorAll('.event-card')].map(e=>({story:e.getAttribute('data-story'),text:e.textContent})), modals:[...document.querySelectorAll('.story-modal')].map(e=>({class:e.className,text:e.textContent})), homeVisible:[...document.querySelectorAll('.lord-card[data-home-petition]')].some(e=>e.getBoundingClientRect().width>0) }))});
 await page.waitForTimeout(4500);
 await snapshot('after-auto-open');
 const target = page.locator('.event-chip[data-story="home_petition"]');
 if (await target.count()) { await target.first().click(); await page.waitForTimeout(1000); await snapshot('after-exact-chip'); }
 const decide = page.locator('.event-card[data-story="home_petition"] .event-card-decide');
 if (await decide.count()) { await decide.first().click(); await page.waitForTimeout(1000); await snapshot('after-exact-decision'); }
 await page.screenshot({path:`${out}/shot.jpg`,type:'jpeg',quality:55});
 await context.close();
} catch(e) { report.errors.push(String(e)); process.exitCode=1; }
finally { await browser?.close(); server.kill('SIGTERM'); closeSync(log); writeFileSync(`${out}/report.json`, JSON.stringify(report,null,2)+'\n'); }
console.log(JSON.stringify(report));
