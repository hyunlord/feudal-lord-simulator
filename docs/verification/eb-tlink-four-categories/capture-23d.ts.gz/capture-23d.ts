import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,mkdirSync,existsSync} from 'node:fs';
import {resolve,join,relative} from 'node:path';
import {fileURLToPath} from 'node:url';
import {gunzipSync,gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {LORD_SLICE_SCENARIO_ID} from '../../src/content/lordSliceConfig';
import {newGameState} from '../../src/state/newGame';
import {gameReducer} from '../../src/state/gameStore';
import {advanceTick} from '../../src/engine/tick';
import {lordBotCommands} from '../../src/engine/lordBot';
import {createTlinkParityObserver,canonicalTlinkRuleState,TLINK_PARITY_EXCLUSIONS} from '../../scripts/engineBTlinkParity';
import {refuseHeavyOnMac} from '../../scripts/remote/localGuard.mjs';
const SOURCE='23d12264289538de5f6ef3ef3f36aa9257b10aba';
const PINS={"1": {"manifest": "60a3349c66ebe4358c7e16b0523be25418b4b4b3ea1f26cc0b11f14b104657ca", "preflight": "e8062e9f432ecb86647540efb9cac0531d4364f8773f96480c746f7125fb7dba", "classification": "139d539762f004344548a72d973234f6d509d01ae7e7a76b399c2ab770820936", "parity": "376058e9ac370d222722b7247eeb82ccc0fffabb082ea5dba1417d4f353dd147", "heavy": 245, "unclassified": 0}, "2": {"manifest": "2c19eefe15a366f75752579620fa3b968ab5d5cf8d2b8cad26cad32fd29827e9", "preflight": "705570725fd39a45ca39875529c62df36ae379c3529b0b53c1f55be8dae1fe11", "classification": "7dbd0443097b1523cfdb823a438144b4db1af2b16458c1b54b330830fbf3a8e6", "parity": "174cafc6412357656695679dfd8b422cda9c28955c58aaadae6673e2779123bb", "heavy": 282, "unclassified": 2}, "3": {"manifest": "77889870fab414a39aa645d339407d280ed4829af25e9c5888d7a8614f0149da", "preflight": "1a13ad0bc39be53483ce84eaea4ec4bab49c84529bff1c44b44b850948d57afc", "classification": "66e23a817f7e2fc256891f16b5f9f214fdd4ffd2e851c9dce3399a0539085809", "parity": "4cf1d7e52dcb00a2f839f49d1645f7da6be2988e33a5bd46356137c322ffd5e3", "heavy": 309, "unclassified": 0}};
const sha=(bytes:string|Uint8Array)=>createHash('sha256').update(bytes).digest('hex');
const [data,seedArg,output,...extra]=process.argv.slice(2);
assert.ok(data&&seedArg&&output&&!extra.length,'usage: node --import tsx .omo/evidence/tlink-immediate-replay.ts DATA_DIR SEED NEW_OUTPUT_DIR');
assert.ok(seedArg==='1'||seedArg==='2'||seedArg==='3');const seed=Number(seedArg),pins=PINS[seedArg];
refuseHeavyOnMac('Full original immediate-evidence replay',{remote:'Official run.sh --heavy --experiment only'});
assert.equal(process.platform,'linux');assert.equal(process.version,'v24.21.0');
const self=fileURLToPath(import.meta.url),repo=process.cwd();
assert.equal(relative(repo,self),'.omo/evidence/tlink-immediate-replay.ts');
const status=execFileSync('git',['status','--porcelain','--untracked-files=all'],{encoding:'utf8'}).trim();
assert.ok(status===''||status==='?? .omo/evidence/tlink-immediate-replay.ts','Only exact runtime helper may be untracked');
assert.ok(!existsSync(output),'Output must be new');mkdirSync(output,{recursive:false});
const inputHashes:Record<string,string>={};
const directory=join(resolve(data),`seed-${seed}`);
function read(name:string){const bytes=readFileSync(join(directory,name));inputHashes[name]=sha(bytes);return bytes;}
let tick=0,ordinal=0;
const files:{file:string;sha256:string;rawSha256:string;ordinal:number;historyId:string|null}[]=[];
try{
 const manifestBytes=read('manifest.json');assert.equal(sha(manifestBytes),pins.manifest);
 const manifest=JSON.parse(manifestBytes.toString());assert.equal(manifest.sourceRevision,SOURCE);
 assert.equal(manifest.seed,seed);assert.equal(manifest.years,125);assert.equal(manifest.valid,true);assert.equal(manifest.replayVerified,true);
 const preflightBytes=read('preflight.json');assert.equal(sha(preflightBytes),pins.preflight);
 const preflight=JSON.parse(preflightBytes.toString());assert.equal(preflight.sourceRevision,SOURCE);
 assert.deepEqual(preflight.sourceFiles,manifest.sourceFiles);assert.equal(preflight.sourceFiles.length,1449);
 const sourcePaths=execFileSync('git',['ls-files','src'],{encoding:'utf8'}).trim().split('\n').sort();
 assert.deepEqual(sourcePaths,preflight.sourceFiles.map((p:{path:string})=>p.path).sort());
 for(const pin of preflight.sourceFiles as {path:string;sha256:string}[])assert.equal(sha(readFileSync(pin.path)),pin.sha256,`source drift ${pin.path}`);
 assert.deepEqual(preflight.toolHashes,manifest.toolHashes);
 for(const [name,pin] of Object.entries(preflight.toolHashes))assert.equal(sha(readFileSync(join('scripts',name))),pin,`tool drift ${name}`);
 assert.equal(preflight.source.node,process.version);assert.equal(sha(readFileSync('package-lock.json')),preflight.source.lock);
 const contextsBytes=read('original-contexts.json.gz');assert.equal(sha(contextsBytes),manifest.contextSha256);
 const contexts=JSON.parse(gunzipSync(contextsBytes).toString()) as {ordinal:number;tick:number;command:Parameters<typeof gameReducer>[1];history?:{id:string}|null}[];
 const classifiedBytes=read('answer-classification.json');assert.equal(sha(classifiedBytes),pins.classification);
 const classification=JSON.parse(classifiedBytes.toString());
 assert.equal(classification.rows.length,manifest.commandCount);assert.equal(contexts.length,manifest.commandCount);
 const selected=new Map<number,{historyId:string|null;status:string;cameHeavyToLord:boolean|null}>();
 for(let index=0;index<contexts.length;index++){
  const c=contexts[index],row=classification.rows[index];assert.equal(c.ordinal,index+1);assert.equal(row.ordinal,c.ordinal);
  assert.equal(row.tick,c.tick);assert.equal(row.command,c.command.type);assert.equal(row.historyId,c.history?.id??null);
  if(row.status==='classified'&&row.cameHeavyToLord===true||row.status==='unclassified')selected.set(c.ordinal,row);
 }
 assert.equal([...selected.values()].filter(r=>r.status==='classified').length,pins.heavy);
 assert.equal([...selected.values()].filter(r=>r.status==='unclassified').length,pins.unclassified);
 const parityBytes=read('collect-parity.json');assert.equal(sha(parityBytes),pins.parity);const expectedParity=JSON.parse(parityBytes.toString());
 const originalBytes=gunzipSync(read('original-final-state.json.gz'));
 assert.equal(sha(originalBytes),manifest.finalComparison.expectedSha256);assert.equal(manifest.finalComparison.actualSha256,manifest.finalComparison.expectedSha256);
 assert.equal(manifest.final.hit,true);assert.equal(manifest.final.tick,500000);
 assert.equal(manifest.final.stateSha,sha(originalBytes),'Manifest final state pin mismatch');
 let state=newGameState({scenarioId:LORD_SLICE_SCENARIO_ID,seed});assert.ok(state&&state.tick===0);
 const parity=createTlinkParityObserver({seasonLength:1000}),stream=createHash('sha256');
 parity.observe(state,{phase:'initial',commandOrdinal:0});const started=Date.now();
 while(state.tick<500000){
  assert.ok(Date.now()-started<2*60*60*1000,'Two-hour replay wall bound exceeded');
  for(const {command} of lordBotCommands(state)){
   const expected=contexts[ordinal];assert.ok(expected);assert.equal(expected.tick,state.tick);assert.deepEqual(command,expected.command);
   const chosen=selected.get(ordinal+1),before=state;
   const beforeRaw=chosen?JSON.stringify(before):null;
   const beforeProjection=chosen?canonicalTlinkRuleState(before):null;
   state=gameReducer(before,command);ordinal++;
   stream.update(`${JSON.stringify({ordinal,tick:before.tick,command})}\n`);
   parity.observe(state,{phase:'command',commandOrdinal:ordinal});
   if(expected.history){
    assert.ok(!before.history?.records.some(r=>r.id===expected.history?.id),'Expected answer ID already existed');
    const fresh=state.history?.records.filter(r=>r.id===expected.history?.id);
    assert.equal(fresh?.length,1,'Own answer identity drift');
    assert.equal(fresh?.[0]?.kind,'decision');assert.equal(fresh?.[0]?.tick,before.tick);
   }
   if(chosen){
    assert.ok(beforeRaw!==null&&beforeProjection!==null);
    const afterRaw=JSON.stringify(state),afterProjection=canonicalTlinkRuleState(state);
    const beforeValue:unknown=JSON.parse(beforeProjection),afterValue:unknown=JSON.parse(afterProjection);
    const differences=diff(beforeValue,afterValue);
    assert.equal(JSON.stringify(before),beforeRaw,'Before-state mutation during reduction/observation');
    assert.equal(JSON.stringify(state),afterRaw,'After-state mutation during observation');
    const record={schemaVersion:1,seed,ordinal,tick:state.tick,historyId:chosen.historyId,command,classificationStatus:chosen.status,
     cameHeavyToLord:chosen.cameHeavyToLord,mature:state.tick+12000<=500000,exclusions:TLINK_PARITY_EXCLUSIONS,
     rawBeforeSha256:sha(beforeRaw),rawAfterSha256:sha(afterRaw),beforeRuleSha256:sha(beforeProjection),afterRuleSha256:sha(afterProjection),
     before:beforeValue,after:afterValue,differences,observerStateHashesStable:true,categoriesAssigned:false};
    const bytes=Buffer.from(JSON.stringify(record)+'\n'),compressed=gzipSync(bytes),file=`answer-${String(ordinal).padStart(6,'0')}.json.gz`;
    writeFileSync(join(output,file),compressed,{flag:'wx'});files.push({file,sha256:sha(compressed),rawSha256:sha(bytes),ordinal,historyId:chosen.historyId});
   }
  }
  state=advanceTick(state);tick=state.tick;parity.observe(state,{phase:'tick',commandOrdinal:ordinal});
  if(tick%10000===0)console.log(JSON.stringify({seed,tick,ordinal,captured:files.length,elapsedSeconds:(Date.now()-started)/1000}));
 }
 parity.observe(state,{phase:'final',commandOrdinal:ordinal});assert.deepEqual(parity.snapshot(),expectedParity,'Original complete collect parity mismatch');
 assert.equal(ordinal,contexts.length);assert.equal(stream.digest('hex'),manifest.commandStreamSha256);
 assert.equal(sha(JSON.stringify(state)+'\n'),sha(originalBytes),'Exact original final-state bytes mismatch');assert.equal(files.length,selected.size);
 writeFileSync(join(output,'manifest.json'),JSON.stringify({schemaVersion:1,status:'verified_original_replay_observer_capture',sourceRevision:SOURCE,
  executionHead:execFileSync('git',['rev-parse','HEAD'],{encoding:'utf8'}).trim(),seed,years:125,tick,commandCount:ordinal,
  originalManifestSha256:sha(manifestBytes),inputHashes,sourceFiles:preflight.sourceFiles,toolHashes:preflight.toolHashes,node:process.version,lockSha256:preflight.source.lock,
  helperSha256:sha(readFileSync(self)),files,selectedHeavy:pins.heavy,unclassified:pins.unclassified,commandStreamMatched:true,collectParityMatched:true,
  fullFinalStateMatched:true,originalFullFinalSha256:sha(originalBytes),exclusions:TLINK_PARITY_EXCLUSIONS,categoriesAssigned:false,
  limits:['Per-command immediate evidence only; no new categorization or score computation.','Raw hash stability and original replay parity constrain observer mutation; no causal effect inferred from bookkeeping changes.']},null,2)+'\n',{flag:'wx'});
}catch(error){
 writeFileSync(join(output,'failure.json'),JSON.stringify({status:'failed_incomplete_capture_not_evidence',seed,tick,ordinal,error:String(error),inputHashes,helperSha256:sha(readFileSync(self)),partialFiles:files},null,2)+'\n',{flag:'wx'});throw error;
}
type Delta={path:string;beforePresent:boolean;afterPresent:boolean;before?:unknown;after?:unknown};
function diff(before:unknown,after:unknown,path=''):Delta[]{
 if(Object.is(before,after))return [];
 if(before===null||after===null||typeof before!=='object'||typeof after!=='object'||Array.isArray(before)!==Array.isArray(after))return [{path:path||'/',beforePresent:true,afterPresent:true,before,after}];
 const a=Object.fromEntries(Object.entries(before)),b=Object.fromEntries(Object.entries(after));const result:Delta[]=[];
 for(const key of [...new Set([...Object.keys(a),...Object.keys(b)])].sort()){
  const next=`${path}/${key.replace(/~/g,'~0').replace(/\//g,'~1')}`;
  if(!Object.hasOwn(a,key)||!Object.hasOwn(b,key))result.push({path:next,beforePresent:Object.hasOwn(a,key),afterPresent:Object.hasOwn(b,key),...(Object.hasOwn(a,key)?{before:a[key]}:{}),...(Object.hasOwn(b,key)?{after:b[key]}:{})});
  else result.push(...diff(a[key],b[key],next));
 }
 return result;
}
