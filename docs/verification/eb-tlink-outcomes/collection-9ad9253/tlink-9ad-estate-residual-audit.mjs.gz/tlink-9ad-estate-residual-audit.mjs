import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
const revision = '9ad9253468592e7cba144946081d2fbced36adca';
const base = '.remote-runs/engineB-tlink-final125-9ad9253/eb-tlink-final';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const inputs = [];
function read(path, pin) {
  const bytes = readFileSync(path), digest = sha(bytes);
  if (pin) assert.equal(digest, pin, path);
  const plain = path.endsWith('.gz') ? gunzipSync(bytes) : bytes;
  inputs.push({ path, sha256: digest, uncompressedSha256: sha(plain) });
  return JSON.parse(plain.toString());
}
const provisional = read('.omo/evidence/tlink-9ad-three-seed-provisional-links.json');
const sourcePins = ['src/engine/decisionTraceEstateRelations.ts', 'src/engine/stewardship.ts',
  'src/content/stewardshipConfig.ts', 'src/engine/decisionTrace.types.ts'].map(path => {
  const bytes = execFileSync('git', ['show', `${revision}:${path}`]);
  return { path, revision, sha256: sha(bytes), currentBytesEqual: bytes.equals(readFileSync(path)) };
});
const rows = [];
for (const summary of provisional.seeds) {
  const seed = summary.seed;
  assert.equal(summary.sourceRevision, revision);
  const rawPath = `${base}/seed-${seed}.json`, contextsPath = `${base}/seed-${seed}/original-contexts.json.gz`;
  const raw = read(rawPath, summary.inputs.find(row => row.path === rawPath)?.sha256);
  const contexts = read(contextsPath, summary.inputs.find(row => row.path === contextsPath)?.sha256);
  const statePath = `${base}/seed-${seed}/original-final-state.json.gz`;
  const statePin = summary.comparison['original-final-state.json.gz'].inputs.find(row => row.path === statePath);
  assert.ok(statePin);
  const state = read(statePath, statePin.sha256);
  assert.equal(inputs.at(-1).uncompressedSha256, statePin.rawSha256);
  assert.equal(raw.provenance.sourceRevision, revision);
  for (const pin of sourcePins) assert.equal(raw.provenance.sourceFiles.find(row => row.path === pin.path)?.sha256, pin.sha256);
  const oldRaw = read(`.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype/seed-${seed}.json`);
  const residual = summary.rows.filter(row => row.command === 'answer_estate_petition' && row.mature && !row.directReceipts.length);
  assert.equal(residual.length, { 1: 86, 2: 110, 3: 140 }[seed]);
  for (const row of residual) {
    const matching = state.trace.answers.filter(answer => answer.id === row.historyId); assert.equal(matching.length, 1);
    const own = matching[0]; assert.equal(own.tick, row.tick); assert.equal(own.source, row.source);
    const context = contexts.find(item => item.history?.id === own.id); assert.ok(context);
    const petition = context.context.estateBefore, settled = context.context.estateAfter;
    assert.ok(petition && settled); assert.equal(context.command.type, 'answer_estate_petition');
    const evidence = (own.estateRelationEvidence ?? []).map(proof => {
      assert.equal(proof.actual, proof.after - proof.before);
      let reason;
      if (!proof.actual) reason = 'answer_relation_zero_at_clamp';
      else if (proof.actual !== proof.intended) reason = 'answer_relation_partial_clamp';
      else if (Math.abs(proof.after) === 100) reason = 'answer_reaches_boundary';
      else if (proof.status === 'invalidated') reason = 'later_invalidation_exact_branch_not_retained';
      else reason = `retained_${proof.status}`;
      return { ...proof, diagnosticReason: reason,
        reasonScope: reason.startsWith('answer_') ? 'proved_from_answer_time_values_and_frozen_source' : 'status_observed_subcause_not_serialized' };
    });
    const observedFuture = raw.history.filter(record => record.kind !== 'decision' && record.tick > own.tick
      && record.tick <= Math.min(raw.endTick, own.tick + 12000) && record.because?.some(cause => cause.decisionId === own.id));
    assert.equal(observedFuture.length, 0);
    rows.push({ seed, historyId: own.id, tick: own.tick, source: own.source, estateId: petition.estateId,
      petitionId: petition.id, kind: petition.kind, grant: context.command.grant, amount: petition.amount,
      statusBefore: petition.status, statusAfter: settled.status, decidedBy: settled.decidedBy,
      sameTickReceipts: row.sameTickReceipts, evidence,
      beforeFirstSeasonCommands: contexts.filter(item => item.ordinal > context.ordinal && item.tick < evidence[0].firstSeasonTick
        && (item.command.estateId === petition.estateId || item.context?.estateBefore?.estateId === petition.estateId
          || (item.command.type === 'answer_audit' && state.stewardship?.audits.find(audit => audit.id === item.command.auditId)?.estateId === petition.estateId)))
        .map(item => {
          const nextOwn = state.trace.answers.find(answer => answer.id === item.history?.id);
          const step = nextOwn?.estateRelationEvidence?.find(proof => proof.estateId === petition.estateId && proof.dimension === evidence[0].dimension);
          return { ordinal: item.ordinal, tick: item.tick, command: item.command, stateChanged: item.stateChanged,
            historyId: item.history?.id ?? null, ownSource: nextOwn?.source ?? null, ownTargets: nextOwn?.targets ?? [], sameDimensionProof: step ?? null,
            oppositeNonzeroDelta: step ? Math.sign(step.actual) !== Math.sign(evidence[0].actual) && step.actual !== 0 : false,
            simpleMarginalInterior: step ? [step.before - evidence[0].actual, step.after - evidence[0].actual].every(value => value > -100 && value < 100) : null };
        }),
      firstSeasonExistingRecords: raw.history.filter(record => record.tick === evidence[0].firstSeasonTick
        && record.template === 'stewardship.season' && (record.params?.traceEstate === petition.estateId
          || record.params?.house === state.estates.estates.find(estate => estate.id === petition.estateId)?.name))
        .map(record => ({ id: record.id, tick: record.tick, params: record.params, because: record.because })),
      noRelationEvidence: evidence.length === 0,
      prior0b04FutureRecords: oldRaw.history.filter(record => record.kind !== 'decision' && record.tick > own.tick
        && record.tick <= own.tick + 12000 && record.because?.some(cause => cause.decisionId === own.id)).map(record => ({ id: record.id, tick: record.tick, template: record.template })),
      fullAnswerNoOp: 'not_inferred_from_relation_delta',
      nextProofNeeded: evidence.some(proof => proof.diagnosticReason === 'later_invalidation_exact_branch_not_retained')
        ? 'Need actual first invalidation before/after snapshot or reason witness: command conflict, unknown oversight mutation, season clamp/counterfactual boundary, identity/record ambiguity, expiry. Current final status cannot distinguish.'
        : 'Relation zero/clamp does not erase independent treasury/income/neglect/charter effects; require their actual state deltas and later consumer before attributing a future receipt.' });
  }
}
assert.equal(rows.length, 336);
function count(items, key) { return Object.fromEntries([...new Set(items.map(key))].sort().map(value => [value, items.filter(row => key(row) === value).length])); }
const proofs = rows.flatMap(row => row.evidence);
const summary = { exactResidualAnswers: rows.length, bySeed: count(rows, row => row.seed),
  byChoice: count(rows, row => `${row.kind}:${row.grant ? 'grant' : 'refuse'}`),
  byEvidenceStatus: count(proofs, row => row.status), byDiagnosticReason: count(proofs, row => row.diagnosticReason),
  byActualIntended: count(proofs, row => `${row.dimension}:actual=${row.actual}:intended=${row.intended}`),
  noEvidence: rows.filter(row => !row.evidence.length).length,
  nonzeroRelationAnswers: rows.filter(row => row.evidence.some(proof => proof.actual !== 0)).length,
  zeroOnlyRelationAnswers: rows.filter(row => row.evidence.length && row.evidence.every(proof => proof.actual === 0)).length,
  laterInvalidationExpectedAtBoundary: proofs.filter(row => row.diagnosticReason.startsWith('later_') && Math.abs(row.expected) === 100).length,
  laterInvalidationExpectedUnchanged: proofs.filter(row => row.diagnosticReason.startsWith('later_') && row.expected === row.after).length,
  laterInvalidationExpectedChangedInterior: proofs.filter(row => row.diagnosticReason.startsWith('later_') && row.expected !== row.after && Math.abs(row.expected) < 100).length,
  fullAnswerNoOpCount: null };
const laterRows = rows.filter(row => row.evidence.some(proof => proof.diagnosticReason.startsWith('later_')));
summary.laterWithOppositeKnownCommand = laterRows.filter(row => row.beforeFirstSeasonCommands.some(command => command.oppositeNonzeroDelta)).length;
summary.laterWithOversightOrAuditModeCommand = laterRows.filter(row => row.beforeFirstSeasonCommands.some(command => ['set_estate_oversight', 'set_audit_mode'].includes(command.command.type) && command.stateChanged)).length;
summary.laterWithAnyRecordedEstateCommand = laterRows.filter(row => row.beforeFirstSeasonCommands.length).length;
summary.laterWithFirstSeasonCollectedRecord = laterRows.filter(row => row.firstSeasonExistingRecords.length).length;
summary.relationZeroGrantWithPositiveAmount = rows.filter(row => row.evidence.every(proof => proof.actual === 0) && row.grant && row.amount > 0).length;
summary.laterWithProvedSubsequentOversightChange = laterRows.filter(row => row.beforeFirstSeasonCommands.some(command => command.ownTargets.includes(`oversight:${row.estateId}`))).length;
summary.laterWithOnlyTolerateWitness = laterRows.filter(row => row.beforeFirstSeasonCommands.length && row.beforeFirstSeasonCommands.every(command => command.command.type === 'answer_audit' && command.command.choice === 'tolerate')).length;
summary.relationZeroCharterRefusal = rows.filter(row => row.evidence.every(proof => proof.actual === 0) && row.kind === 'charter_request' && !row.grant).length;
const result = { status: 'collection_only_replay_pending_not_formal_acceptance', revision,
  reproduction: 'node .omo/evidence/tlink-9ad-estate-residual-audit.mjs',
  scriptSha256: sha(readFileSync('.omo/evidence/tlink-9ad-estate-residual-audit.mjs')),
  metricScope: 'Exact 336 mature unlinked direct answer_estate_petition own IDs from provisional 301/816; no scorer changes.',
  summary, sourcePins, inputs, rows,
  investigationPriority: {
    boundaryInvalidations: '54 later-invalidated rows retain expected at +/-100, consistent with later saturation; this alone does not identify the first invalidation branch.',
    interiorInvalidations: '62 later-invalidated rows retain interior expected (56 unchanged, 6 changed). Best bounded diagnostic target, not 62 proven missing links: capture the exact first invalidation branch and real before/after oversight/summary/record identity.',
    nonRelationEffects: 'Repair/relief grants also post immediate negative petition.amount cash (stewardship.ts:487-493). That is a real separate effect, not automatically a future outcome. Charter refusal has relation-only direct effect in petitionEffect; petition bookkeeping still changes.',
    mixedCommandObservedUpperBound: '0 of these 116 has a recorded opposite-sign same-dimension answer_estate_petition before firstSeasonTick. The mixed-command proof does not establish a gain in this residual set.',
    oversightWitnesses: '6 rows have a later actual own trace target oversight:<same estate>, proving a mode/steward change occurred; separately, 2 rows have set_audit_mode commands. They do not prove the first invalidation tick: prior per-tick state is absent. Tolerate preserves oversight object and cannot alone explain invalidation.',
    firstInvalidation: 'Unknown for all 116 from this archive. No unlinked stewardship.season records are present at their firstSeasonTick; final expected is the value at invalidation but no timestamp/branch is stored. Repeated failed audit attempts are listed as attempts, not counted as actual swaps.',
    zeroRelationSeparateEffects: '86 zero-relation grants (repair68/relief18) have positive petition.amount and successful settlement; frozen handler posts -amount cash independently of clamp. 127 zero-relation charter refusals still settle the petition, but their direct effect table has no cash or neglect effect. No full-answer-noop extrapolation.',
    missingLinkUpperBound: 'At most 116 initially interior nonzero rows are candidates for broad follow-up; 62 retain interior expected and are a narrower diagnostic priority. These are investigation ceilings, not predicted recoverable links. Known mixed-command gain in this exact set is 0.',
    minimalExperiment: 'Use a prepared actual checkpoint and real reducer/first-next-season for one representative of each 116-row subgroup; observe invalidation without changing state/IDs, verify actual and marginal unclamped relation. Do not annotate all invalidated contributors.'
  },
  limits: ['Final evidence contains status but no invalidation-reason field.',
    'Actual zero refers only to the named relation dimension, never the whole answer.',
    'Nonzero answer delta alone does not prove retained next-season contribution or any future cash result.',
    'No engine ticks, replay, or new remote jobs were run.'] };
writeFileSync('.omo/evidence/tlink-9ad-estate-residual-audit.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
