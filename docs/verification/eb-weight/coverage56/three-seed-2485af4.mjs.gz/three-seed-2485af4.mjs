// Offline, exact occurrence-answer coverage. No simulation or browser invocation.
import { readFileSync, writeFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { summarizeRegistryAnswers } from '../../scripts/engineBRegistryAnswerAudit.mjs';
import { summarizeWeightAudit } from '../../scripts/engineBWeightAuditSummary.ts';
import { registryV4Support } from '../../src/engine/registryV4.ts';
const prefix = '.omo/evidence/eb-56-three-seed-coverage';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const sources = {};
const read = (key, path, pin) => {
  const bytes = readFileSync(path), hash = sha(bytes);
  if (pin) assert.equal(hash, pin);
  sources[key] = { path, sha256: hash };
  return JSON.parse(bytes);
};
const inventory = read('inventory', 'docs/verification/eb-weight/layers.json');
const sourceRevision = '2485af40046793f1856829fa1161dc4431942aa7';
const rawPins = ['3cf11889398f36ac8dc8c0230dc509d5e46cbaa8abdcd1f568d7a0744600dbfd', '9e3737c46b4825564510f1748f36d0abef4376824cf34bf57237d89ba50663be', '2973df33958f226900d1dcc219c890f4635488b725e88316bbfc7932fc28eb99'];
const manifestPins = ['e4615d5a01c18d7b6adba9f3eec12c570f0ab14041266e947305674c04e2b93d', '766a84d5db46f5a91777f885f11c0a249b3e84aec3169635216201efb1b3553e', '0a1f2527ced012082f4127516680f5b5d95e16ca469881bcc8708fe4a37478e0'];
const ids = inventory.events.map(event => event.id);
assert.equal(ids.length, 56); assert.equal(new Set(ids).size, 56);
const current = registryV4Support().filter(entry => entry.runs);
assert.deepEqual(current.map(e => e.id).sort(), [...ids].sort());
for (const event of inventory.events) assert.deepEqual(event.supportedChoices.map(c => c.id).sort(), current.find(e => e.id === event.id).choices.filter(c => c.supported).map(c => c.id).sort());
const inputs = [1, 2, 3].map(seed => {
  const raw = read(`seed${seed}`, `.omo/evidence/weight125-kept-partial/seed-${seed}.json`, rawPins[seed - 1]);
  const directory = `.omo/evidence/weight125-kept-partial/checkpoints${seed === 1 ? '' : '-seed' + seed}`;
  const manifest = read(`manifest${seed}`, `${directory}/manifest.json`, manifestPins[seed - 1]);
  assert.deepEqual(manifest, raw.checkpointManifest); assert.equal(raw.seed, seed);
  assert.equal(raw.provenance.sourceRevision, sourceRevision); assert.equal(raw.provenance.dirtyPaths, '');
  assert.equal(raw.endTick, 500000); assert.deepEqual([...raw.support.enabledIds].sort(), [...ids].sort());
  assert.deepEqual(summarizeWeightAudit(raw), raw.summary);
  const audit = summarizeRegistryAnswers(raw);
  return { seed, raw, manifest, audit, directory };
});
const browser = read('browser', '.remote-runs/render-EB-visible-current-1866075/eb-visible-current/results.json');
const browser2 = read('browser2', '.remote-runs/render-EB-seed2-visible-14c4849/eb-visible-seed2/results.json', '2f08d387648f5110970017a9f7c2218f4d46053e15cc2ccc46cf6a1a3400cffb');
assert.equal(browser2.sourceRevision, '14c4849d4e0cc2efde48abdfa99edb4f44e94910');
assert.equal(browser2.cases.length, 8);
assert.equal(browser2.checkpointSourceRevision, sourceRevision);
assert.equal(browser2.manifestSha256, manifestPins[1]);
assert.equal(browser2.run, false);
assert.equal(browser2.dirtyPaths, '');
for (const c of browser2.cases) { assert.deepEqual(c.errors, []); assert.equal(c.tickUnchanged, true); assert.equal(c.finalHistoryTraceExact, true); }
const steward = read('steward', '.remote-runs/render-EB-steward-history-2ec110e/eb-steward-chronicle/results.json');
assert.equal(browser.sourceRevision, '18660752adef3d7632e9aac3a6b211f6a7e0e549');
assert.equal(browser.cases.length, 31);
for (const b of [browser, steward]) { assert.equal(b.checkpointSourceRevision, sourceRevision); assert.equal(b.manifestSha256, manifestPins[0]); assert.equal(b.run, false); }
for (const path of ['scripts/engineBRegistryAnswerAudit.mjs', 'scripts/engineBWeightAuditSummary.ts', 'src/engine/registryV4.ts', 'src/content/registry/v4Entries.generated.ts']) sources[path] = { path, sha256: sha(readFileSync(path)) };
const asset = (archive, file) => ({ path: `${sources[archive].path.slice(0, -'results.json'.length)}${file}`, sha256: sha(readFileSync(`${sources[archive].path.slice(0, -'results.json'.length)}${file}`)) });
const coverage = rows => ({ counted: rows.length, directWithFuture: rows.filter(a => a.directFuture.length).length,
  withoutDirectFuture: rows.filter(a => !a.directFuture.length).map(a => a.answerHistoryId) });
const entries = inventory.events.map(event => {
  const supportedChoices = event.supportedChoices.map(choice => choice.id);
  const seeds = inputs.map(({ seed, raw, manifest, audit, directory }) => {
    const occurrences = raw.occurrences.filter(o => o.entryId === event.id && o.offeredTick >= 0 && o.offeredTick < 500000);
    const answers = audit.answers.filter(a => a.entryId === event.id);
    assert(answers.every(a => supportedChoices.includes(a.choiceId)));
    const pair = manifest.pairs.find(p => p.entryId === event.id) ?? null;
    return { seed, occurrences: occurrences.length, statuses: Object.fromEntries([...new Set(occurrences.map(o => o.status))].map(s => [s, occurrences.filter(o => o.status === s).length])),
      counts: audit.perEntry.find(p => p.entryId === event.id), answers: answers.map(a => ({ ...a,
        directFirstDelayTicks: a.directFuture.length ? a.directFuture[0].tick - a.settledTick : null,
        directFirstDelaySeasons: a.directFuture.length ? (a.directFuture[0].tick - a.settledTick) / 1000 : null })),
      unresolved: audit.unresolved.filter(u => occurrences.some(o => o.id === u.occurrenceId)),
      stewardCoverage: { mature: coverage(answers.filter(a => a.by === 'steward' && a.mature)), rightCensored: coverage(answers.filter(a => a.by === 'steward' && !a.mature)) },
      firstSavedPair: pair === null ? null : { directory, ...pair, delayTicks: pair.consequence ? pair.consequence.historyTick - pair.decisionTick : null,
        delaySeasons: pair.consequence ? (pair.consequence.historyTick - pair.decisionTick) / 1000 : null },
      rootMatterDecisions: raw.summary.decisions.filter(d => d.kind === 'registry' && d.source.split(':')[1] === event.id) };
  });
  const ui = [{ seed: 1, archive: 'browser', data: browser }, { seed: 2, archive: 'browser2', data: browser2 }].flatMap(({ seed, archive, data }) => data.cases.filter(c => c.pair?.entryId === event.id).map(c => {
    assert.deepEqual(c.pair, inputs[seed - 1].manifest.pairs.find(p => p.entryId === event.id));
    const expectedSave = c.name.endsWith('-answer') ? c.pair.answer : c.pair.consequence ?? inputs[seed - 1].manifest.finalSave;
    assert.deepEqual(c.checkpoint, expectedSave);
    const detail = c.panels.find(p => p.shown && p.screenshot.endsWith('-decision.png'));
    const immediateRelation = detail?.panel?.text?.match(/[^\n]*관계 [−-]2[^\n]*/)?.[0] ?? null;
    return { seed, archive, sourceRevision: data.sourceRevision, name: c.name, expectedDecisionId: c.pair.decisionId, choice: c.pair.source.split(':')[2],
      tick: c.checkpoint.observedTick, decisionLocated: c.decisionLocated ?? false,
      directPairShown: c.exactConsequenceLinkShown === true && c.exactCauseBackLinkShown === true,
      errors: c.errors, tickUnchanged: c.tickUnchanged, historyTraceExact: c.finalHistoryTraceExact,
      initialPresentationExact: c.initialPresentationStateExact, finalPresentationExact: c.finalPresentationStateExact,
      presentationDifference: c.finalPresentationDifference ?? null, presentationUnchangedDuringCapture: c.presentationUnchangedDuringCapture,
      chipSelectedRecords: c.chipSelectedRecords ?? [], chipMatchesExpectedDecision: c.chipMatchesExpectedDecision ?? null,
      immediateEffectUI: { relationMinusTwoText: immediateRelation, shownInExactDecisionDetail: c.decisionLocated === true && immediateRelation !== null, scope: 'Immediate relationship memory text; not a future consequence/because link', decisionDetailText: detail?.panel?.text ?? null },
      screenshots: c.panels.map(p => ({ ...asset(archive, p.screenshot), selector: p.selector, shown: p.shown })) };
  }));
  const stewardUI = steward.cases.filter(c => c.entry === event.id).map(c => ({ seed: 1, id: c.id, choice: c.decision.source.split(':')[2],
    exactSelected: c.exactSelected, errors: c.errors, initial: c.initial, final: c.final, screenshot: asset('steward', c.screenshot),
    scope: 'Manually selected same-occurrence chronicle history; NOT seasonal steward report' }));
  const all = seeds.flatMap(s => s.answers.map(a => ({ seed: s.seed, ...a })));
  const choices = supportedChoices.map(choice => ({ choice, bySeed: seeds.map(s => ({ seed: s.seed,
    lord: s.answers.filter(a => a.choiceId === choice && a.by === 'lord').length,
    steward: s.answers.filter(a => a.choiceId === choice && a.by === 'steward').length })),
    actualAnswerIdentities: all.filter(a => a.choiceId === choice).map(a => ({ seed: a.seed, occurrenceId: a.occurrenceId, answerHistoryId: a.answerHistoryId, by: a.by })) }));
  const observed = seeds.some(s => s.occurrences > 0), actualUI = ui.some(u => u.decisionLocated && !u.errors.length) || stewardUI.some(u => u.exactSelected && !u.errors.length);
  const invalidOnly = observed && all.length === 0 && seeds.every(s => (s.statuses.invalid ?? 0) === s.occurrences);
  const acceptedAnswerWithoutUI = all.length > 0 && !actualUI;
  const remaining = [];
  if (!observed) remaining.push('No occurrence in three original seeds');
  if (invalidOnly) remaining.push('Only invalid attempts observed; no accepted answer (not an accepted-answer UI gap)');
  else if (observed && !actualUI) remaining.push('Engine observed but no actual UI witness');
  const unseenChoices = choices.filter(c => !c.actualAnswerIdentities.length).map(c => c.choice);
  if (unseenChoices.length) remaining.push('Unanswered supported choices: ' + unseenChoices.join(','));
  if (all.some(a => a.by === 'lord' && a.mature && !a.directFuture.length)) remaining.push('Mature lord answer lacks direct future because link');
  if (all.some(a => !a.mature)) remaining.push('Right-censored answer window');
  if (ui.some(u => u.chipMatchesExpectedDecision === false)) remaining.push('Automatic chip selected another decision before manual navigation');
  if (all.some(a => a.directFirstDelaySeasons > 4)) remaining.push('Some first direct outcomes exceed4seasons (screening threshold, not agreed few-seasons acceptance)');
  if (all.some(a => a.by === 'steward')) remaining.push('Seasonal stewardReport actual UI absent; chronicle/model evidence distinct');
  if (ui.some(u => !u.finalPresentationExact)) remaining.push('Presentation state difference retained in UI artifact');
  remaining.push('Live first-season/10x delivery not verified');
  if (!ui.some(u => u.seed === 2)) remaining.push('No seed2 UI replay for this ID');
  remaining.push('No seed3 UI replay');
  return { id: event.id, supportedChoices, choices, seeds, ui, stewardUI, observed, actualUI, invalidOnly, acceptedAnswerWithoutUI, unseenChoices, remaining };
});
for (const input of inputs) {
  for (const key of ['lordAnswered', 'stewardAnswered']) assert.equal(entries.reduce((n,e) => n + e.seeds.find(s => s.seed === input.seed).counts[key], 0), input.audit.counts[key]);
  assert.equal(entries.reduce((n,e) => n + e.seeds.find(s => s.seed === input.seed).occurrences, 0), input.audit.counts.occurrences);
}
const counts = { ids: entries.length, supportedChoices: entries.reduce((n,e) => n + e.supportedChoices.length, 0),
  occurredIds: entries.filter(e => e.observed).length, unobservedIds: entries.filter(e => !e.observed).length,
  observedAnswerChoices: entries.reduce((n,e) => n + e.choices.filter(c => c.actualAnswerIdentities.length).length, 0),
  invalidOnlyIds: entries.filter(e => e.invalidOnly).length, acceptedAnswerWithoutUIIds: entries.filter(e => e.acceptedAnswerWithoutUI).length,
  actualUIIds: entries.filter(e => e.actualUI).length, observedWithoutUIIds: entries.filter(e => e.observed && !e.actualUI).length,
  seed1PairedUIIds: entries.filter(e => e.ui.some(u => u.seed === 1 && u.directPairShown && !u.errors.length)).length,
  seed1AnswerOnlyUIIds: entries.filter(e => e.ui.some(u => u.seed === 1 && u.decisionLocated && !u.errors.length) && !e.ui.some(u => u.seed === 1 && u.directPairShown)).length,
  allPairedUIIds: entries.filter(e => e.ui.some(u => u.directPairShown && !u.errors.length)).length,
  allAnswerOnlyUIIds: entries.filter(e => e.ui.some(u => u.decisionLocated && !u.errors.length) && !e.ui.some(u => u.directPairShown)).length,
  stewardChronicleIds: entries.filter(e => e.stewardUI.some(u => u.exactSelected && !u.errors.length)).length };
assert.equal(counts.supportedChoices, 163); assert.equal(counts.seed1PairedUIIds, 13); assert.equal(counts.stewardChronicleIds, 4); assert.equal(counts.actualUIIds, 23); assert.equal(counts.allPairedUIIds, 15); assert.equal(counts.allAnswerOnlyUIIds, 4); assert.equal(counts.observedWithoutUIIds, 3);
assert.deepEqual(entries.filter(e => e.invalidOnly).map(e => e.id), ['ck_evt_010', 'ck_evt_051', 'ck_evt_059']);
assert.equal(counts.acceptedAnswerWithoutUIIds, 0);
const immediate209 = entries.find(e => e.id === 'ck_evt_209').ui.filter(u => u.seed === 2 && u.immediateEffectUI.shownInExactDecisionDetail);
assert(immediate209.length > 0); assert(immediate209.every(u => !u.directPairShown));
const output = { status: 'partial_three_seed_engine_and_seed1_seed2_paused_UI_not_full56_completion', sourceRevision,
  validatorRevision: execFileSync('git', ['rev-parse','HEAD'], { encoding: 'utf8' }).trim(), sources,
  browserSources: { current31: browser.sourceRevision, seed2Eight: browser2.sourceRevision, stewardHistory: steward.sourceRevision }, counts,
  scope: ['Exact unique occurrence→answer history join is the primary unit; retained root matters are separately included, never summed as occurrence answers.',
    'Only direct because membership strictly after answer within12000ticks and endpoint counts as direct consequence; inferredRoot candidates remain noncanonical.',
    'Mature means full12000tick future window; right-censored absence is not failure.',
    'UI witnesses are existing paused seed1 and selected seed2 saves, manual navigation. No automatic seasonal report, live10x, all choices, or all56 claim.',
    'Full raw evidence and screenshots hash-pinned; saves previously validated officially, no new save decode/browser/simulation in this aggregation.'],
  perSeed: inputs.map(i => ({ seed: i.seed, counts: i.audit.counts, coverage: i.audit.coverage,
    savedPairs: i.manifest.pairs.length, savedLinkedPairs: i.manifest.pairs.filter(p => p.consequence).length, limits: i.audit.limits })),
  invalidOnlyIds: entries.filter(e => e.invalidOnly).map(e => e.id), acceptedAnswerWithoutUIIds: entries.filter(e => e.acceptedAnswerWithoutUI).map(e => e.id),
  unobservedIds: entries.filter(e => !e.observed).map(e => e.id), observedWithoutUIIds: entries.filter(e => e.observed && !e.actualUI).map(e => e.id), entries };
writeFileSync(prefix + '.json', JSON.stringify(output,null,2)+'\n');
const lines = ['# Exact56 coverage: three original seeds + existing seed1/seed2 UI', '', '**PARTIAL; not full-goal closure.** Reproduce offline: `node --import tsx .omo/evidence/eb-56-three-seed-coverage.mjs`.', '',
  `Engine source ${sourceRevision}; current31 UI source ${browser.sourceRevision}; seed2 eight-case UI source ${browser2.sourceRevision}; steward chronicle source ${steward.sourceRevision}. All source/raw/manifest/results/screenshot hashes and per-answer identities are in sibling JSON.`, '',
  `Verified56 current enabled IDs and163 supported choices exactly match layers inventory. Observed IDs ${counts.occurredIds}/56; actual answered choice IDs ${counts.observedAnswerChoices}/163; UI IDs ${counts.actualUIIds}; paired UI${counts.allPairedUIIds} (seed1 13 + seed2 2), answer-only UI${counts.allAnswerOnlyUIIds} (seed1 2 + seed2 2), separate steward chronicle4.`, '', ...output.scope.map(s => '- '+s), '',
  '| ID | choices answered/supported | seed1/2/3 occurrence; lord/steward | mature direct/answers by seed | censored direct/answers by seed | saved pairs by seed | actual UI | remaining |',
  '|---|---|---|---|---|---|---|---|'];
for (const e of entries) lines.push(`| ${e.id} | ${e.choices.filter(c=>c.actualAnswerIdentities.length).map(c=>c.choice).join(',')||'none'} / ${e.supportedChoices.join(',')} | ${e.seeds.map(s=>`${s.occurrences};${s.counts.lordAnswered}/${s.counts.stewardAnswered}`).join(' · ')} | ${e.seeds.map(s=>`${s.counts.matureLord.directWithFuture}/${s.counts.matureLord.counted}`).join(' · ')} | ${e.seeds.map(s=>`${s.counts.censoredLord.directWithFuture}/${s.counts.censoredLord.counted}`).join(' · ')} | ${e.seeds.map(s=>s.firstSavedPair?(s.firstSavedPair.consequence?`linked(${s.firstSavedPair.delaySeasons.toFixed(2)}seasons)`:'answer-only'):'none').join(' · ')} | ${e.ui.some(u=>u.directPairShown)?'manual paired':e.ui.some(u=>u.decisionLocated)?'manual answer-only':'none'}${e.stewardUI.length?'; steward history':''} | ${e.remaining.join('; ')} |`);
lines.push('', '## Minimal remaining matrix', '', 'Full56 has30 unobserved IDs; historical40 subset has29. The additional full56-unobserved ID is015, so the denominators must not be conflated.', '', `No occurrence: ${output.unobservedIds.join(', ')}.`, '', `Occurrence observed without UI: ${output.observedWithoutUIIds.join(', ')}. These are invalid-only IDs: ${output.invalidOnlyIds.join(', ')}; no accepted answer exists in these three seeds. Accepted-answer IDs without any UI witness: ${output.acceptedAnswerWithoutUIIds.length}. This does not establish all-answer or seasonal UI coverage.`, '',
  'Per-choice missed identities, per-seed censored/direct-unlinked answers, chip-selected exact record IDs and >4season first delays are retained in JSON. The4season screen merely separates longer timings; it does not redefine the user’s few-seasons criterion. 038/140 manual answer-only witnesses do not manufacture consequences. Current31 /seen presentation differences are preserved, not silently promoted to exact full-state passes. Four steward chronicle captures are not seasonal stewardReport captures.', '',
  'Seed2 ck_evt_209 exact decision detail visibly records relation−2; this immediate relationship memory is distinct from an absent later future because link. Exact text and screenshot SHA are retained in JSON. Seed1 and seed2 wrong chip targets and presentation differences remain separate per case.', '',
  'Existing visual review remains REVISE for blank prediction/actual columns and CJK wrapping. No new screenshots viewed or captured by this aggregation. All56/all163 choice meaning, actual seasonal delivery, live10x and remaining engine/UI gaps stay open.');
writeFileSync(prefix+'.md',lines.join('\n')+'\n');console.log(JSON.stringify({counts,perSeed:output.perSeed.map(({limits,...s})=>s)},null,2));
