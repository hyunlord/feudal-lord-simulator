import {readFileSync,writeFileSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
import {execFileSync} from 'node:child_process';
const revision='0b04cd0becc4d73059fbfcf372395c8672d1a381';
const canonicalPath='src/content/registry/v4Entries.generated.ts';
const canonicalBytes=execFileSync('git',['show',`${revision}:${canonicalPath}`],{maxBuffer:10_000_000});
const canonical=JSON.parse(canonicalBytes.toString().split('export const V4_LIVE_ENTRIES: unknown = ')[1].split('\n')[0].trim().replace(/;$/, '')); 
const sha=b=>createHash('sha256').update(b).digest('hex');
const input=n=>`.omo/evidence/prototype-0b04-${n}.json`;
const scoreBytes=readFileSync(input('score')),residualBytes=readFileSync(input('residuals')),configBytes=readFileSync(input('config'));
const score=JSON.parse(scoreBytes),residual=JSON.parse(residualBytes),config=JSON.parse(configBytes),base=dirname(resolve(input('config')));
assert.equal(residual.originalScoreSha256,sha(scoreBytes));assert.equal(score.configSha256,sha(configBytes));
const contractBytes=readFileSync(resolve(base,config.contractFile));assert.equal(sha(contractBytes),config.contractSha256);const contract=JSON.parse(contractBytes);
const inputs=[['score',scoreBytes],['residuals',residualBytes],['config',configBytes]].map(([name,bytes])=>({path:input(name),sha256:sha(bytes)}));
const rows=[];
for(const seed of config.seeds){
 const dir=join(resolve(base,config.replayDirectory),`seed-${seed}`),rawPath=join(resolve(base,config.rawDirectory),`seed-${seed}.json`);
 const rawBytes=readFileSync(rawPath),manifestBytes=readFileSync(join(dir,'manifest.json')),manifest=JSON.parse(manifestBytes),raw=JSON.parse(rawBytes);
 const pin=config.replayPins.find(x=>x.seed===seed);assert.equal(sha(rawBytes),pin.rawSha256);assert.equal(sha(manifestBytes),pin.manifestSha256);
 const contextBytes=readFileSync(join(dir,'original-contexts.json.gz'));assert.equal(sha(contextBytes),manifest.contextSha256);
 const contexts=JSON.parse(gunzipSync(contextBytes));inputs.push({seed,rawSha256:sha(rawBytes),manifestSha256:sha(manifestBytes),contextsSha256:sha(contextBytes)});
 for(const row of residual.residuals.filter(x=>x.seed===seed&&x.category==='unexplained')){
  const answer=score.answers.find(x=>x.seed===seed&&x.historyId===row.historyId);assert.ok(answer);
  const matches=contexts.filter(x=>x.ordinal===row.ordinal&&x.history?.id===row.historyId&&x.tick===row.tick);assert.equal(matches.length,1);
  const context=matches[0];const own=raw.history.find(x=>x.id===row.historyId);const atAnswer=structuredClone(own); if(atAnswer.decision) delete atAnswer.decision.actual; const captured=structuredClone(context.history); if(captured.decision) delete captured.decision.actual; assert.deepEqual(captured,atAnswer);
  const receipts=raw.history.filter(h=>h.kind!=='decision'&&h.tick===row.tick&&h.because?.some(c=>c.decisionId===row.historyId));
  const parts=answer.source?.split(':');const event=parts?.[0]==='registry'?contract.events.find(e=>e.id===parts[1]):null;const choice=event?.choices.find(c=>c.id===parts[2]);
  const canonEvent=event?canonical.find(e=>e.id===event.id):null;const canonChoice=canonEvent?.choices.find(c=>c.id===parts[2]);
  if(choice?.commands.length===0){assert.equal(canonChoice.commands.length,0);assert.equal(raw.provenance.sourceFiles.find(x=>x.path===canonicalPath).sha256,sha(canonicalBytes));}
  rows.push({seed,historyId:row.historyId,tick:row.tick,ordinal:row.ordinal,command:context.command,source:answer.source,
   ownHistory:own,receipts:receipts.map(h=>({id:h.id,tick:h.tick,kind:h.kind,template:h.template,params:h.params,because:h.because})),
   candidate:receipts.length?'exact_own_same_tick_domain_record_not_future':'no_exact_own_same_tick_domain_record',
   auditIdentity:context.command.type==='answer_audit'?{commandAuditId:context.command.auditId??null,ownSubjectId:own.params?.subjectId??null,
    receiptAuditIds:receipts.map(h=>h.params?.auditId??h.params?.audit??null),retainedContextKeys:Object.keys(context.context??{}),
    limitation:'Exact per-attempt command/history join; no audit-before/after snapshot or estate ID inferred from steward/name.'}:null,
   canonicalHold:choice?.commands.length===0?{entryId:event.id,choiceId:choice.id,commands:choice.commands,canonicalRef:{revision,path:canonicalPath,sha256:sha(canonicalBytes),selector:`id=${event.id}/choices/id=${choice.id}/commands`},contractSha256:sha(contractBytes),sourceRefs:choice.outcomes.flatMap(o=>o.sourceRefs)}:null,
   sourcePins:raw.provenance.sourceFiles.filter(x=>['src/engine/history.ts','src/engine/decisionTraceAnswerReceipts.ts','src/engine/stewardship.ts','src/content/registry/v4Entries.generated.ts'].includes(x.path))});
 }
}
const count=key=>Object.fromEntries([...new Set(rows.map(key))].map(k=>[k,rows.filter(x=>key(x)===k).length]));
const report={status:'offline_evidence_inventory_not_reclassification',inputs,originalMetric:score.legacyDirectRatio,
 summary:{unexplained:rows.length,withSameTick:rows.filter(x=>x.receipts.length).length,withoutSameTick:rows.filter(x=>!x.receipts.length).length,
 canonicalCommandless:rows.filter(x=>x.canonicalHold).length,withSameTickByCommand:count(x=>x.receipts.length?x.command.type:'none')},rows,
 limits:['No scorer/residual/category/denominator change. Same-tick receipts never counted as future.', 'Domain processing evidence does not prove nonzero state change or later effect. Audit ID absent in receipt remains absent.']};
assert.equal(rows.length,179);
writeFileSync('.omo/evidence/tlink-immediate-own-receipts.json',JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report.summary));
