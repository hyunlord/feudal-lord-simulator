import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { classifyAnswerEvidence } from '../../scripts/engineBOutcomeEvidence';
const dir = '.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype';
const rawPath = `${dir}/seed-1.json`, contextPath = `${dir}/seed-1/original-contexts.json.gz`;
const rawBytes = readFileSync(rawPath), contextsBytes = readFileSync(contextPath);
const raw = JSON.parse(rawBytes.toString());
const classification = classifyAnswerEvidence(JSON.parse(gunzipSync(contextsBytes).toString()));
const baselinePath = 'docs/verification/eb-tlink-outcomes/baseline-score.json.gz';
const baselineBytes = readFileSync(baselinePath);
const baseline = JSON.parse(gunzipSync(baselineBytes).toString()).answers.filter(row => row.seed === 1);
const rows = classification.rows.filter(row => row.status === 'classified' && row.cameHeavyToLord === true).map(answer => {
  const linked = raw.history.filter(record => record.kind !== 'decision' && record.because?.some(cause => cause.decisionId === answer.historyId));
  const future = linked.filter(record => record.tick > answer.tick && record.tick <= Math.min(raw.endTick, answer.tick + 12000));
  const prior = baseline.find(row => row.historyId === answer.historyId);
  return { historyId: answer.historyId, ordinal: answer.ordinal, tick: answer.tick, command: answer.command, source: answer.source,
    mature: answer.tick + 12000 <= raw.endTick, directReceipts: future.map(record => ({ id: record.id, tick: record.tick, template: record.template })),
    sameTickReceipts: linked.filter(record => record.tick === answer.tick).map(record => ({ id: record.id, template: record.template })),
    baselineDirectReceipts: prior?.directReceipts ?? [] };
});
const unlinked = rows.filter(row => row.mature && row.directReceipts.length === 0);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const result = { status: 'collection_only_unverified_replay_not_gate', sourceRevision: raw.provenance.sourceRevision,
  formula: 'classified cameHeavyToLord true; mature answer.tick+12000<=endTick; nondecision because exact own historyId, answer.tick<receipt.tick<=min(endTick,answer.tick+12000)',
  inputs: [{ path: rawPath, sha256: sha(rawBytes) }, { path: contextPath, sha256: sha(contextsBytes) }, { path: baselinePath, sha256: sha(baselineBytes) }],
  summary: { heavy: rows.length, mature: rows.filter(row => row.mature).length, direct: rows.filter(row => row.mature && row.directReceipts.length > 0).length, unlinked: unlinked.length },
  auditTolerateUnlinkedIds: unlinked.filter(row => row.command === 'answer_audit' && row.source?.startsWith('audit:tolerate:')).map(row => row.historyId),
  rows };
writeFileSync('.omo/evidence/tlink-seed1-provisional-links.json', JSON.stringify(result, null, 2)+'\n');
console.log(JSON.stringify({ summary: result.summary, auditTolerateUnlinkedIds: result.auditTolerateUnlinkedIds }));
