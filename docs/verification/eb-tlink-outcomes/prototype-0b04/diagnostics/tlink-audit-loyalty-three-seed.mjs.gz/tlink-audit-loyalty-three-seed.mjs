import assert from 'node:assert/strict';
import {readFileSync,writeFileSync} from 'node:fs';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
import {execFileSync} from 'node:child_process';
import {hashSeed} from '../../src/content/seedHash.ts';
const revision='0b04cd0becc4d73059fbfcf372395c8672d1a381';
const directory='.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype';
const sha=bytes=>createHash('sha256').update(bytes).digest('hex');
const sourceFiles=['src/engine/stewardship.ts','src/content/stewardshipConfig.ts','src/content/seedHash.ts','src/engine/prng.ts'].map(path=>{
 const pinned=execFileSync('git',['show',`${revision}:${path}`]);assert.deepEqual(readFileSync(path),pinned,`source drift ${path}`);return{path,revision,sha256:sha(pinned)};
});
const configPath='.omo/evidence/prototype-0b04-config.json',residualPath='.omo/evidence/prototype-0b04-residuals.json',scorePath='.omo/evidence/prototype-0b04-score.json';
const configBytes=readFileSync(configPath),residualBytes=readFileSync(residualPath),scoreBytes=readFileSync(scorePath);
const config=JSON.parse(configBytes),residual=JSON.parse(residualBytes),score=JSON.parse(scoreBytes);
assert.equal(score.configSha256,sha(configBytes));assert.equal(residual.originalScoreSha256,sha(scoreBytes));
const seeds=[1,2,3].map(seed=>{
 const inputs=[];
 const read=(name,gzip=false)=>{const path=`${directory}/${name}`,bytes=readFileSync(path);inputs.push({path,sha256:sha(bytes)});return JSON.parse(gzip?gunzipSync(bytes).toString():bytes.toString());};
 const raw=read(`seed-${seed}.json`),manifest=read(`seed-${seed}/manifest.json`),validity=read(`seed-${seed}/validity.json`);
 const pins=config.replayPins.find(row=>row.seed===seed);assert.equal(inputs[0].sha256,pins.rawSha256);assert.equal(inputs[1].sha256,pins.manifestSha256);assert.equal(validity.manifestSha256,pins.manifestSha256);assert.equal(validity.valid,true);assert.equal(manifest.replayVerified,true);assert.equal(raw.provenance.sourceRevision,revision);
 const state=read(`seed-${seed}/original-final-state.json.gz`,true),contexts=read(`seed-${seed}/original-contexts.json.gz`,true);
 assert.equal(inputs.at(-1).sha256,manifest.contextSha256);assert.equal(sha(gunzipSync(readFileSync(inputs.at(-2).path))),manifest.final.stateSha);
 for(const pin of sourceFiles)assert.equal(raw.provenance.sourceFiles.find(row=>row.path===pin.path)?.sha256,pin.sha256);
 assert.equal(state.seed,seed);assert.equal(state.tick,500000);
 const ss=state.stewardship;assert.deepEqual(ss.audits.map(row=>row.id),Array.from({length:ss.nextAudit-1},(_,i)=>`audit-${i+1}`));
 const explicit=contexts.filter(row=>row.command.type==='answer_audit'&&row.command.choice==='tolerate');const commands=new Map(explicit.map(row=>[row.command.auditId,row]));assert.equal(commands.size,explicit.length);
 const ids=new Set(residual.residuals.filter(row=>row.seed===seed&&row.command==='answer_audit'&&row.category==='unexplained').map(row=>row.historyId));
 const answers=[],stewards=[];
 for(const steward of ss.stewards){
  const peers=ss.stewards.filter(row=>row.estateId===steward.estateId),index=peers.findIndex(row=>row.personId===steward.personId),number=Number(steward.estateId.replace(/\D+/g,''))||0;
  assert.equal(steward.disposition,['merchant','peasant','greedy'][index%3]);assert.equal(steward.ability,30+hashSeed(seed,'steward:ability',number,index)%61);
  let loyalty=steward.disposition==='greedy'?20+hashSeed(seed,'steward:loyalty',number,index)%31:55+hashSeed(seed,'steward:loyalty',number,index)%36;
  const initial=loyalty,sequence=[];let deadline=-1;
  for(const audit of ss.audits.filter(row=>row.stewardId===steward.personId)){
   assert.ok(audit.tick>deadline,'overlapping audit windows');deadline=audit.deadline;assert.equal(audit.estateId,steward.estateId);
   const before=loyalty;if(audit.status==='tolerated')loyalty=Math.min(100,loyalty+10);
   const context=commands.get(audit.id);
   if(context){assert.equal(audit.status,'tolerated');assert.equal(context.history.params.subjectId,audit.id);assert.ok(context.tick>=audit.tick&&context.tick<=audit.deadline);assert.equal(context.stateChanged,true);}
   const event={auditId:audit.id,auditTick:audit.tick,deadline:audit.deadline,status:audit.status,before,after:loyalty,delta:loyalty-before,historyId:context?.history?.id??null,answerTick:context?.tick??null,ordinal:context?.ordinal??null};sequence.push(event);
   if(context)answers.push({...event,seed,stewardId:steward.personId,estateId:steward.estateId,residual:ids.has(context.history.id)});
  }
  assert.equal(loyalty,steward.loyalty,`final mismatch ${steward.personId}`);stewards.push({personId:steward.personId,estateId:steward.estateId,candidateIndex:index,initial,recomputed:loyalty,observed:steward.loyalty,matched:true,sequence});
 }
 assert.equal(answers.length,explicit.length);assert.equal(answers.filter(row=>row.residual).length,ids.size);
 return{seed,inputs,stewards,answers,counts:{stewardsMatched:stewards.length,explicit:answers.length,residual:ids.size,positive:answers.filter(row=>row.residual&&row.delta>0).length,zero:answers.filter(row=>row.residual&&row.delta===0).length}};
});
const total=Object.fromEntries(Object.keys(seeds[0].counts).map(key=>[key,seeds.reduce((sum,row)=>sum+row.counts[key],0)]));assert.equal(total.stewardsMatched,42);assert.equal(total.residual,94);assert.equal(total.positive,27);assert.equal(total.zero,67);
const result={kind:'source_derived_loyalty_fold_not_future_effect_proof',sourceRevision:revision,scriptSha256:sha(readFileSync(new URL(import.meta.url))),sourceFiles,
 inputs:[{path:configPath,sha256:sha(configBytes)},{path:residualPath,sha256:sha(residualBytes)},{path:scorePath,sha256:sha(scoreBytes)}],
 total,futureEffectProven:0,candidateUpperBound:27,seeds,
 limits:['Source-derived before/after loyalty, not captured audit-time snapshots or engine replay.','27 is a candidate upper bound only. No future kept/error/reported difference proved.','All 94 residual answers remain in the unchanged mature denominator. No scorer or residual category changed.','Non-explicit tolerated audits are folded for the sole loyalty writer but not assigned to invented answer IDs.'],
 reproduce:'node --import tsx .omo/evidence/tlink-audit-loyalty-three-seed.mjs'};
writeFileSync('.omo/evidence/tlink-audit-loyalty-three-seed.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});console.log(JSON.stringify({total,scriptSha256:result.scriptSha256,resultSha256:sha(readFileSync('.omo/evidence/tlink-audit-loyalty-three-seed.json'))}));
