# Provisional charter-refusal relation fold feasibility

Source: `0b04cd0becc4d73059fbfcf372395c8672d1a381`. Seed 1 collection only; replay/terminal acceptance remains outside this audit. Input and source SHA256 pins are in [the JSON](tlink-charter-fold-feasibility.json); the [offline helper](tlink-charter-fold-feasibility.py) imports no engine and advances no game ticks.

## Result

A source-derived forward fold is feasible for `estate-neighbour-3` merchants: 449 consecutive season petitions (ticks 52000–500000), 138 exact lord before/after contexts, 15 retained oversight changes, and immutable retained steward dispositions account for the merchant writers. None of these petitions is open/lapsed. The fold starts at source-defined zero, not the final clamp. All eight retained season summary merchant values and final merchants −100 agree.

Of 71 charter refusals, 19 have merchants −100 → −100; 17 have a complete 12000-tick observation window, two are censored. The retained collector currently has no future own-ID receipt for these 19. Full identities/ordinals/ticks are in the JSON. There is no all-direct estate subset: oversight mode changes are explicitly reconstructed.

## Exact safe causal claim

`stewardship.ts:175–186` defines a refused charter effect as income 0, tenants 0, merchants −8, neglect false, kept 0. `answerEstatePetition` at lines 471–499 applies no cash posting when income is zero, no neglect when false, and changes no rights/policy/estate ownership field. It settles the petition to refused/decidedBy lord and clamps the two relation fields. Thus these 19 answers have a proven zero **numeric merchant relation delta**, with no immediate treasury/tenant/neglect/rights mutation in this handler. They still have an actual settlement effect. Off-map history at `history.ts:1094–1106` records that settlement; unlike the home branch (1075–1091), it does not add faction relation changes.

The fold covers merchant changes in `stewardship.ts:282–354`: petition effects, overload wait, lapse branch (absent here), rate drift and clamp. Initialization is 128–144; replacement is 149–166; tick order is 399–405; oversight changes preserve relations at 416–428. Source configuration pins include the rates and effect constants. Positive-severity initial/oversight records are retained; `history.ts:620–624` only folds eligible severity-zero records. Final values are consistency checks, not reconstruction inputs.

## Why this is not a full-domain no-op or impossibility proof

Settlement excludes the petition from future open-petition selection (`stewardship.ts:437–439`) and future lapse penalties (293–300). It also increments the retained `steward.lordDecided` registry input (`registry.ts:133`). This is a concrete future-consumer path even if its threshold is already met; this audit does not prove the threshold's marginal outcome for every row. The petition's `rights` flag remains a classification fact, not a granted property right. No counterfactual simulation or complete future-consumer equivalence proof was performed. No new future receipt or denominator exemption is warranted.

For audit tolerance, `stewardship.ts:544–551` changes pending → tolerated even when loyalty clamps at 100. It prevents another answer (`534`, `546`, `568`) and removes automatic lapse eligibility (`384–389`); automatic lapse would itself tolerate the audit. This branch changes no income/tenants/oversight/kept/errors. `history.ts:1109–1126` records settlement and gives faction effects only to punishment. Registry answer success reads audit status (`registryV4.ts:111`, `registry.ts:212`). These status/control-flow effects prohibit treating a loyalty no-op alone as complete command equivalence. This note does not independently certify the other agent's audit counts.

Even combining the parent's 26 mature audit loyalty-noops with these 17 mature charter relation-noops yields only 43/238, fewer than the 49 unlinked rows needed to force a rate below 80%. Neither set establishes full-domain/future impossibility. Primary measurement and denominator remain unchanged.

## No-op identities

| Own answer ID | Tick | Mature 3-year window |
|---|---:|---|
| `h-014460` | 219025 | yes |
| `h-014642` | 222067 | yes |
| `h-014825` | 225031 | yes |
| `h-014988` | 228073 | yes |
| `h-015677` | 240007 | yes |
| `h-015810` | 242035 | yes |
| `h-016960` | 259039 | yes |
| `h-017032` | 260053 | yes |
| `h-017663` | 270037 | yes |
| `h-018652` | 285013 | yes |
| `h-018719` | 286027 | yes |
| `h-029581` | 455053 | yes |
| `h-029724` | 457003 | yes |
| `h-030196` | 464023 | yes |
| `h-030271` | 465037 | yes |
| `h-030780` | 472057 | yes |
| `h-031622` | 484069 | yes |
| `h-032527` | 497017 | no |
| `h-032648` | 499045 | no |
