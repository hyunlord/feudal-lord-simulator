# EB-TLINK estate relation mixed-command proof note

Scope: proof sketch only; no implementation or scorer change. Product source baseline is `9ad925346` (`Retain proved answer influence through opposing seasonal relation drift`). The current worktree HEAD `72b157bb0` has the same source hashes for the files below; only documentation is modified in the worktree at the time of this note.

## Source pins

| Path | Revision | SHA-256 |
|---|---:|---|
| `src/engine/decisionTraceEstateRelations.ts` | `9ad925346` | `4fcc895cc73ed2b4bca3f8d23d8bfc5a077d4a841836d7387ff74769d4845eeb` |
| `src/engine/stewardship.ts` | `9ad925346` | `0ee5cbc4f8024c035915cae2f74a40e5db3eccaeab21ec13ecfc061ecf0bcff4` |
| `src/content/stewardshipConfig.ts` | `9ad925346` | `aa01e8e7a7929122d75cd26fadce98459d86ff2893eec57a64ea8a03533e5949` |

## Current source facts

`commandEvidence` records only real lord `answer_estate_petition` commands for non-home estates, and only marks a proof pending when the actual command delta equals the intended petition effect and the actual post-command relation is strict interior. See `src/engine/decisionTraceEstateRelations.ts:16-30`.

The current command-chain logic invalidates a pending proof when a later same-estate/same-dimension known command has the opposite sign. See `src/engine/decisionTraceEstateRelations.ts:46-50` and the conflict applied to the new answer at `src/engine/decisionTraceEstateRelations.ts:57-60`.

The petition delta table is source-independent of the prior tenant/merchant value. See `src/engine/stewardship.ts:175-184`. Lord answers apply that fixed delta and clamp once at `src/engine/stewardship.ts:487-498`.

The seasonal path already uses a strict-interior marginal rule because seasonal increments are accumulated independently and clamped once. See `src/engine/decisionTraceEstateRelations.ts:100-104` and `src/engine/stewardship.ts:289-349`.

## Proof sketch

For a tracked estate/dimension, let an answer `i` have retained command delta `d_i = row.actual`. At each later known `answer_estate_petition` command step, the engine computes a fixed source-table delta `s_t` independent of the previous relation, then stores `clamp(x + s_t)`. If the actual result `x_t` is strict interior and the per-answer-removal counterfactual `x_t - d_i` is also strict interior at every known step boundary, the clamp is inactive in both actual and counterfactual paths. Therefore removing answer `i` from the sequence yields exactly `x_t - d_i` by induction, even if a later known command has the opposite sign.

Opposite sign is not itself a proof of cancellation or invalidity. Clamp activation, stale expected values, unknown writers, missing oversight, and identity/mode/audit-mode changes are the actual proof breakers.

## Sound provenance rule, not implementation

A pending answer contribution may survive a later same-dimension known command of either sign only when all of these hold:

1. Continuity: the pre-command actual value equals the proof's `expected` value.
2. Known writer: the later step is itself a pending `commandEvidence` row from a real `answer_estate_petition` command.
3. Actual step unclamped: the later step's own `actual === intended` and actual post-step value is strict interior. The existing `step.status === "pending"` already encodes this.
4. Per-answer removal unclamped before and after the step: both `old[dimension] - row.actual` and `current[dimension] - row.actual` are strict interior.
5. Estate identity and steward/mode/audit-mode invariants remain unchanged, as in the current helper.

For the later command's own evidence, the same removal test should hold for itself: `current[dimension] - step.actual` strict interior. If not, its apparent delta depends on clamp and should remain invalidated.

Keep invalidation for unknown commands/tick mutations, stale expected values, missing current/old oversight, identity changes, and any clamp-boundary counterfactual.

## Boundary examples

- Admit mixed command: `0 -> +4 -> -2` where the second command is `-6`. Removing the first answer gives `-6`, both actual `-2` and counterfactual `-6` are interior, so the first answer's retained marginal effect is still `+4`.
- Admit repeated mixed commands when all removal counterfactuals stay interior, for example `0 -> +8 -> +2 -> +6`; each answer can remain proven independently if removing that answer from every subsequent value stays strict interior.
- Reject clamp-dependent mixed command: `-96 -> -92 -> -98` for the `+4` answer followed by `-6`. Removing `+4` at the later boundary gives `-102`, which would clamp to `-100`; the retained `+4` marginal is not source-proven.
- Reject any step where `step.actual !== step.intended`; actual command application already hit clamp.
- Reject unknown mutation between known commands, even if a later value returns to the expected number.
- Do not apply this rule to other command families unless their relation delta is proven source-independent in the same way.

This note does not claim any 3-seed coverage, 80% feasibility, or future metric change.
