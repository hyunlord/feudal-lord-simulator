// Pure offline evidence extraction. Does not execute the engine or assign causal categories.
import { createHash } from 'node:crypto';
import { createReadStream, readFileSync, realpathSync, statSync, writeFileSync } from 'node:fs';
import { basename, dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { validateHistoricalReplayArtifacts } from '../../scripts/engineBHistoricalReplayReport.mjs';

const [directoryArgument, manifestSha256, outputArgument, ...extra] = process.argv.slice(2);
if (!directoryArgument || !/^[a-f0-9]{64}$/.test(manifestSha256 ?? '') || !outputArgument || extra.length) {
  throw new Error('Usage: node .omo/evidence/historical-classification-packets.mjs ACCEPTED_OUTPUT_DIR EXTERNALLY_VERIFIED_MANIFEST_SHA256 NEW_OUTPUT_JSON');
}
const directory = realpathSync(resolve(directoryArgument));
if (!statSync(directory).isDirectory()) throw new Error('Input directory required');
const repository = resolve(dirname(fileURLToPath(import.meta.url)), '../..');
const originals = join(repository, 'docs/verification/lm-e9c-final/distribution');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
function readArtifact(name) {
  if (basename(name) !== name || name === '.' || name === '..') throw new Error('Unsafe artifact name');
  const path = realpathSync(join(directory, name));
  if (dirname(path) !== directory || !statSync(path).isFile()) throw new Error('Artifact must be a file inside input directory');
  return createReadStream(path, { highWaterMark: 256 * 1024 });
}
const manifestBytes = readFileSync(join(directory, 'replay-manifest.json'));
const manifest = JSON.parse(manifestBytes);
const verification = await validateHistoricalReplayArtifacts({
  referenceBundle: {
    runGzip: readFileSync(join(originals, 'run-1.json.gz')),
    reportGzip: readFileSync(join(originals, 'report-1.json.gz')),
    contextGzip: readFileSync(join(originals, 'context.json.gz')),
  },
  manifestBytes, manifestSha256, readArtifact,
});
const packets = new Map(verification.rows.map(row => [row.entryId, {
  entryId: row.entryId, records: 0, gates: {}, eventRows: [],
}]));
if (packets.size !== 40) throw new Error('Expected exact historical40');
const targetTicks = new Set();
const globalOuterRows = [];
const selectionContext = [];
const witness = (line, record) => ({ line, record });
const isEvent = record => record.gate === 'accepted' || record.gate === 'ordered_candidate'
  || record.gate === 'chosen' || record.gate === 'constructed_offer' || record.scope === 'layer';
async function streamRecords(consume) {
  const digest = createHash('sha256');
  const decoder = new TextDecoder('utf-8', { fatal: true });
  let pending = '', line = 0;
  for await (const chunk of readArtifact('candidate-observation.ndjson')) {
    digest.update(chunk);
    pending += decoder.decode(chunk, { stream: true });
    let end;
    while ((end = pending.indexOf('\n')) !== -1) {
      consume(JSON.parse(pending.slice(0, end)), ++line);
      pending = pending.slice(end + 1);
    }
  }
  pending += decoder.decode();
  if (pending !== '' || line !== verification.observations.records
    || digest.digest('hex') !== manifest.artifactSha256['candidate-observation.ndjson']) {
    throw new Error('Observation stream changed after validation');
  }
}
await streamRecords((record, line) => {
  if (record.scope === 'v4_outer') globalOuterRows.push(witness(line, record));
  const packet = packets.get(record.entryId);
  if (!packet) return;
  packet.records += 1;
  const key = `${record.scope}.${record.gate}`;
  const group = packet.gates[key] ??= { count: 0, first: witness(line, record), last: null };
  group.count += 1;
  group.last = witness(line, record);
  if (isEvent(record)) {
    packet.eventRows.push(witness(line, record));
    targetTicks.add(record.tick);
  }
});
// Second pass retains competitors even when their rows precede a target's accepted row.
await streamRecords((record, line) => {
  if (targetTicks.has(record.tick) && (record.scope === 'v4_selection'
    || record.scope === 'legacy_selection' || record.scope === 'v4_outer' || record.scope === 'layer')) {
    selectionContext.push(witness(line, record));
  }
});
for (const row of verification.rows) {
  const packet = packets.get(row.entryId);
  if (packet.records !== row.records || Object.keys(packet.gates).length !== Object.keys(row.gateCounts).length
    || Object.entries(row.gateCounts).some(([key, count]) => packet.gates[key]?.count !== count)) {
    throw new Error(`Packet counts disagree with validated aggregation: ${row.entryId}`);
  }
}
const result = {
  schemaVersion: 1,
  scope: 'Offline evidence packets from supplied validated historical replay artifacts; no causal classification',
  provenance: { directory, manifestSha256, sourceRevision: manifest.sourceRevision, toolRevision: manifest.toolRevision,
    node: manifest.node, extractorSha256: sha(readFileSync(fileURLToPath(import.meta.url))),
    artifactSha256: manifest.artifactSha256 },
  verification,
  packets: [...packets.values()],
  globalOuterRows,
  selectionContextTicks: [...targetTicks].sort((a, b) => a - b),
  selectionContext,
  limits: ['Caller must establish external acceptance; an externally supplied hash is not itself runtime/source verification.',
    'Global outer rows are not attributed to individual entry eligibility.',
    'Same-tick context does not imply same-call identity if multiple calls occurred at that tick; line numbers preserve stream order.',
    'Gate counts are records, not unique seasons or offers. First/last witnesses are stream-order representatives.',
    'Exact enabled-choice counts and internal binding/context rejection details remain unobserved.',
    'No automatic categories, inferred producers, or counterfactual eligibility.'],
  applicabilityAllowed: false, fullStateComparable: false, originalRuntimeVerified: false, completeCausesVerified: false,
};
writeFileSync(resolve(outputArgument), `${JSON.stringify(result, null, 2)}\n`, { flag: 'wx' });
process.stdout.write(`${JSON.stringify({ output: resolve(outputArgument), entries: packets.size,
  records: verification.observations.records, contextTicks: targetTicks.size, applicabilityAllowed: false })}\n`);
