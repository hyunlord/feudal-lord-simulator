import assert from 'node:assert/strict';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import {resolve,dirname} from 'node:path';
import {gunzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const sha=b=>createHash('sha256').update(b).digest('hex');
const [reportPath,captureRoot,residualPath,outputPrefix,...extra]=process.argv.slice(2);
assert.ok(reportPath&&captureRoot&&residualPath&&outputPrefix&&!extra.length,'usage: node HELPER REPORT.json.gz CAPTURE_ROOT RESIDUAL.json NEW_OUTPUT_PREFIX');
assert.ok(!existsSync(outputPrefix+'.json')&&!existsSync(outputPrefix+'.md'),'Both output files must be new');
const compressed=readFileSync(reportPath),raw=gunzipSync(compressed),report=JSON.parse(raw);
assert.equal(readFileSync(resolve(dirname(reportPath),'../exit-code'),'utf8').trim(),'0');
const manifests=new Map();
for(const pin of report.provenance.manifests){const bytes=readFileSync(`${captureRoot}/seed-${pin.seed}/manifest.json`);assert.equal(sha(bytes),pin.sha256);const m=JSON.parse(bytes);assert.equal(m.originalManifestSha256,pin.originalManifestSha256);assert.equal(m.sourceRevision,report.provenance.sourceRevision);assert.equal(m.fullFinalStateMatched,true);assert.equal(m.collectParityMatched,true);assert.equal(m.commandStreamMatched,true);manifests.set(pin.seed,m);}
const same=(a,b)=>assert.deepEqual(a,b);
const rows=[];
const selected=report.answers.filter(r=>r.category==='inert'||(!r.mature&&r.actualImmediateInert));
for(const row of selected){
 const artifact=report.capture.artifacts.find(a=>a.seed===row.seed&&a.historyId===row.historyId);assert.ok(artifact);const a=artifact.artifact;
 const entry=manifests.get(row.seed).files.find(f=>f.ordinal===row.ordinal);assert.equal(entry.historyId,row.historyId);assert.equal(entry.sha256,a.compressedSha256);assert.equal(entry.rawSha256,a.rawSha256);
 const bytes=readFileSync(`${captureRoot}/seed-${row.seed}/${a.file}`);assert.equal(sha(bytes),a.compressedSha256);const payload=gunzipSync(bytes);assert.equal(sha(payload),a.rawSha256);const c=JSON.parse(payload);
 assert.equal(c.historyId,row.historyId);assert.equal(c.ordinal,row.ordinal);assert.equal(c.tick,row.tick);assert.equal(c.seed,row.seed);
 assert.equal(row.actualEffects.length,0);assert.equal(row.proofComplete,true);
 const before=c.before,after=c.after;let detail;
 const b=structuredClone(before),d=structuredClone(after);
 if(c.command.type==='answer_audit'){
  const old=before.stewardship.audits.find(x=>x.id===c.command.auditId),next=after.stewardship.audits.find(x=>x.id===c.command.auditId);assert.ok(old&&next);assert.equal(old.status,'pending');assert.equal(next.status,'tolerated');assert.equal(c.command.choice,'tolerate');
  const bs=before.stewardship.stewards.find(x=>x.personId===old.stewardId),as=after.stewardship.stewards.find(x=>x.personId===old.stewardId);assert.equal(bs.loyalty,100);assert.equal(as.loyalty,100);
  d.stewardship.audits.find(x=>x.id===old.id).status=old.status;
  detail={kind:'audit_tolerate',auditBefore:old,auditAfter:next,stewardBefore:bs,stewardAfter:as,loyaltyDelta:0};
 }else{
  assert.equal(c.command.type,'answer_estate_petition');assert.equal(c.command.grant,false);
  const old=before.stewardship.petitions.find(x=>x.id===c.command.petitionId),next=after.stewardship.petitions.find(x=>x.id===c.command.petitionId);assert.ok(old&&next);assert.equal(old.kind,'charter_request');assert.equal(old.status,'open');assert.equal(next.status,'refused');
  const restored=d.stewardship.petitions.find(x=>x.id===old.id);restored.status=old.status;if(Object.hasOwn(old,'decidedBy'))restored.decidedBy=old.decidedBy;else delete restored.decidedBy;
  const bo=before.stewardship.oversight.find(x=>x.estateId===old.estateId),ao=after.stewardship.oversight.find(x=>x.estateId===old.estateId);same(bo,ao);same(before.treasuryCoin,after.treasuryCoin);
  detail={kind:'charter_refusal',petitionBefore:old,petitionAfter:next,oversightBefore:bo,oversightAfter:ao,cashBefore:before.treasuryCoin,cashAfter:after.treasuryCoin};
 }
 same(b,d); // Entire retained rule state, not only selected numeric fields; only explicit settlement bookkeeping restored.
 rows.push({seed:row.seed,historyId:row.historyId,ordinal:row.ordinal,tick:row.tick,category:row.category,mature:row.mature,source:row.source,command:c.command,artifact:a,allRetainedNonBookkeepingStateEqual:true,detail});
}
const mature=rows.filter(r=>r.mature);assert.equal(mature.length,194);
const counts=values=>Object.fromEntries([...new Set(values)].sort().map(k=>[k,values.filter(x=>x===k).length]));
const residualBytes=readFileSync(residualPath),residual=JSON.parse(residualBytes);
assert.equal(residual.originalScoreSha256,report.originalScoreSha256);
const mapping=residual.residuals.filter(r=>r.category==='unexplained').map(r=>{const to=report.answers.find(a=>a.seed===r.seed&&a.historyId===r.historyId);assert.ok(to);return {seed:r.seed,historyId:r.historyId,command:r.command,newCategory:to.category};});assert.equal(mapping.length,179);
const result={schemaVersion:1,report:{path:reportPath,compressedSha256:sha(compressed),rawSha256:sha(raw)},provenance:report.provenance,helperSha256:sha(readFileSync(new URL(import.meta.url))),matureCounts:counts(mature.map(r=>r.detail.kind)),bySeed:[1,2,3].map(seed=>({seed,counts:counts(mature.filter(r=>r.seed===seed).map(r=>r.detail.kind))})),immatureAnalogues:rows.filter(r=>!r.mature),legacyResidual:{path:residualPath,sha256:sha(residualBytes),counts:counts(mapping.map(r=>r.newCategory)),byCommand:counts(mapping.map(r=>`${r.command}:${r.newCategory}`)),rows:mapping},rows:mature,baseProjectionExclusions:['history','trace.decisions','trace.answers'],limits:['Canonical nonbookkeeping equality only, NOT full raw GameState equality: base projection already excludes history, trace.decisions and trace.answers.','No category reassignment: official report retained.','Only explicit pending/tolerated or open/refused/decidedBy bookkeeping restored for whole canonical-state equality.','Immature analogues are outside the mature816 denominator.','No engine execution or new score computation.']};
writeFileSync(outputPrefix+'.json',JSON.stringify(result,null,2)+'\n',{flag:'wx'});
writeFileSync(outputPrefix+'.md',`# Final inert answer proof\n\nAuthenticated official report; no category reassignment.\n\nMature groups: ${JSON.stringify(result.matureCounts)}.\n\nPer seed: ${JSON.stringify(result.bySeed)}.\n\nImmature analogous cases: ${result.immatureAnalogues.length}, outside denominator.\n\nLegacy179 mapping: ${JSON.stringify(result.legacyResidual.counts)}.\n\nBase projection excludes history, trace.decisions and trace.answers. This is canonical nonbookkeeping equality, not full raw GameState equality. All194 captures passed complete retained rule-state equality after restoring only explicit settlement bookkeeping. Audit loyalty stays100; charter oversight and cash stay equal. JSON retains each exact command, payload, target, before/after values, capture hashes and report/manifest provenance.\n`,{flag:'wx'});
console.log(JSON.stringify({counts:result.matureCounts,bySeed:result.bySeed,immature:result.immatureAnalogues.length,mapping:result.legacyResidual.counts}));
