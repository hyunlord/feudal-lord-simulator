# Offline fold of retained observations only; no engine imports or simulated ticks.
import pathlib,json,gzip,hashlib,collections
root=pathlib.Path.cwd();base=root/'.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype';d=base/'seed-1'
paths=[base/'seed-1.json',d/'original-contexts.json.gz',d/'original-final-state.json.gz',d/'preflight.json']
raw=json.loads(paths[0].read_bytes());contexts=json.loads(gzip.decompress(paths[1].read_bytes()));state=json.loads(gzip.decompress(paths[2].read_bytes()));pre=json.loads(paths[3].read_bytes())
sourcefiles=['src/engine/stewardship.ts','src/content/stewardshipConfig.ts','src/engine/history.ts','scripts/engineBOutcomeEvidence.ts','scripts/engineBOutcomeProduce.ts']
pins={x['path']:x['sha256'] for x in pre['sourceFiles']}
source=[]
for name in sourcefiles:
 sha=hashlib.sha256((root/name).read_bytes()).hexdigest()
 if name.startswith('src/'):assert pins[name]==sha,(name,'source mismatch')
 else:assert pre['toolHashes'][name.split('/')[-1]]==sha,(name,'tool mismatch')
 source.append({'path':name,'sha256':sha})
estate='estate-neighbour-3';history=state['history']['records'];petitions=[p for p in state['stewardship']['petitions'] if p['estateId']==estate]
assert sorted(p['tick'] for p in petitions)==list(range(52000,500001,1000))
assert len({p['id'] for p in petitions})==449
assert not any(p['status'] in ['open','lapsed'] for p in petitions)
byid={p['id']:p for p in petitions};commands=[]
for c in contexts:
 a=c.get('context',{}).get('estateAfter');b=c.get('context',{}).get('estateBefore')
 if not a or a['estateId']!=estate:continue
 assert c['command']['type']=='answer_estate_petition' and c['command']['petitionId']==a['id']==b['id']==c['history']['params']['subjectId']
 assert b['status']=='open' and a['status']==('granted' if c['command']['grant'] else 'refused') and a['decidedBy']=='lord'
 assert a==byid[a['id']] and b['kind']==a['kind'] and b['amount']==a['amount'] and c['tick']<=b['deadline']
 commands.append(c)
assert len(commands)==138 and {c['command']['petitionId'] for c in commands}=={p['id'] for p in petitions if p['decidedBy']=='lord'}
began=[h for h in history if h['template']=='stewardship.began' and h['params']['estate']==estate];assert len(began)==1 and began[0]['tick']==52000
modes=[h for h in history if h['template']=='stewardship.oversight' and h['params']['estate']==estate]
dead={h['tick'] for h in history if h['template']=='stewardship.steward_died'}
assert all(h['tick']%1000 or h['tick'] in dead for h in modes)
assert all(h['severity']>0 for h in modes+began)
stewards={s['personId']:s for s in state['stewardship']['stewards']}
events=[(h['tick'],0,0,'mode',h) for h in modes]+[(p['tick'],1,0,'season',p) for p in petitions]+[(c['tick'],2,c['ordinal'],'answer',c) for c in commands]
merchants=0;mode='direct';steward=began[0]['params']['stewardId'];rows=[];snapshots=[]
def effect(p):
 grant=p['status']=='granted'
 return {'market_dues':8 if grant else -6,'common_dispute':-5 if grant else 5,'charter_request':12 if grant else -8}.get(p['kind'],0)
def clamp(n):return max(-100,min(100,n))
for tick,_,__,kind,value in sorted(events,key=lambda x:x[:3]):
 if kind=='mode':mode=value['params']['mode'];steward=value['params']['stewardId'];continue
 before=merchants
 if kind=='season':
  if value['decidedBy']=='steward':assert mode=='steward';merchants+=effect(value)
  elif value.get('reachesLord') is not None:
   assert mode=='direct'
   if value['group']=='merchants':merchants-=3
  rate=1000 if mode=='direct' else {'merchant':800,'peasant':1000,'greedy':1150}[stewards[steward]['disposition']]
  merchants=clamp(merchants+(1000-rate)*.04)
  snapshots.append({'tick':tick,'merchants':merchants,'mode':mode})
 else:
  p=value['context']['estateAfter'];merchants=clamp(merchants+effect(p))
  if p['kind']=='charter_request' and p['status']=='refused':rows.append({'historyId':value['history']['id'],'ordinal':value['ordinal'],'tick':tick,'petitionId':p['id'],'before':before,'after':merchants,'relationNoop':before==merchants})
assert merchants==state['stewardship']['oversight'][0]['merchants']
last={s['tick']:s for s in state['stewardship']['summaries'] if s['estateId']==estate}
assert all(s['merchants']==last[s['tick']]['merchants'] for s in snapshots if s['tick'] in last)
result={'status':'provisional_source_derived_feasibility_not_accepted_replay','sourceRevision':raw['provenance']['sourceRevision'],'inputs':[{'path':str(p.relative_to(root)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in paths],'sourceFiles':source,'completeness':{'petitions':len(petitions),'lordContexts':len(commands),'modeChanges':len(modes),'lapsed':0,'lastSummaryChecks':len(last)},'charterRefusals':len(rows),'relationNoops':sum(r['relationNoop'] for r in rows),'rows':rows,'limitations':['Source-derived merchants-only fold, not replay or complete gameplay difference.','Final clamp is a cross-check only; fold starts at documented initial zero.','Replay/terminal acceptance pending; do not alter outcome denominator or primary metric.']}
link_path=root/'.omo/evidence/tlink-seed1-provisional-links.json'
links=json.loads(link_path.read_bytes())
assert links['sourceRevision']==result['sourceRevision']
assert links['inputs'][0]['sha256']==result['inputs'][0]['sha256']
assert links['inputs'][1]['sha256']==result['inputs'][1]['sha256']
link_rows={row['historyId']:row for row in links['rows']}
assert len(link_rows)==len(links['rows'])
for row in rows:
 row['mature']=row['tick']+12000<=500000
 if row['relationNoop']:
  other=link_rows[row['historyId']]
  assert (other['ordinal'],other['tick'],other['mature'])==(row['ordinal'],row['tick'],row['mature'])
  assert other['directReceipts']==[]
  row['futureOwnReceiptCount']=0
result['observationWindow']={'endTick':500000,'liveTicks':12000,'maturityFormula':'answer.tick + 12000 <= 500000'}
result['matureRelationNoops']=sum(row['relationNoop'] and row['mature'] for row in rows)
result['censoredRelationNoops']=sum(row['relationNoop'] and not row['mature'] for row in rows)
result['linkCrosscheck']={'path':str(link_path.relative_to(root)),'sha256':hashlib.sha256(link_path.read_bytes()).hexdigest(),'allRelationNoopIdsPresent':True,'allRelationNoopFutureOwnReceiptCountsZero':True}
(root/'.omo/evidence/tlink-charter-fold-feasibility.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['inputs','sourceFiles','rows']},indent=2));print('first_noops', [r for r in rows if r['relationNoop']][:3])
