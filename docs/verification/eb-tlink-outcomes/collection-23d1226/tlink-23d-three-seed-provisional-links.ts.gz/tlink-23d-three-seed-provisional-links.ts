import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { isDeepStrictEqual } from 'node:util';
import { classifyAnswerEvidence } from '../../scripts/engineBOutcomeEvidence';
const prototype = '.remote-runs/engineB-tlink-audit125-23d1226/eb-tlink-audit-final';
const baseline = '.remote-runs/engineB-tlink-baseline125-cf3fa94/eb-tlink-baseline';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const seeds = [1,2,3].map(seed => {
  const rawPath = `${prototype}/seed-${seed}.json`, contextPath = `${prototype}/seed-${seed}/original-contexts.json.gz`;
  const rawBytes = readFileSync(rawPath), contextBytes = readFileSync(contextPath);
  const raw = JSON.parse(rawBytes.toString());
  const classification = classifyAnswerEvidence(JSON.parse(gunzipSync(contextBytes).toString()));
  const rows = classification.rows.filter(row => row.status === 'classified' && row.cameHeavyToLord === true).map(answer => {
    const linked = raw.history.filter(record => record.kind !== 'decision' && record.because?.some(cause => cause.decisionId === answer.historyId));
    const future = linked.filter(record => record.tick > answer.tick && record.tick <= Math.min(raw.endTick, answer.tick + 12000));
    return { seed, historyId: answer.historyId, ordinal: answer.ordinal, tick: answer.tick, command: answer.command, source: answer.source,
      mature: answer.tick + 12000 <= raw.endTick,
      directReceipts: future.map(record => ({ id: record.id, tick: record.tick, template: record.template })),
      sameTickReceipts: linked.filter(record => record.tick === answer.tick).map(record => ({ id: record.id, template: record.template })) };
  });
  const comparison = {};
  for (const file of ['collect-parity.json', 'collect-rule-state.json.gz', 'original-final-state.json.gz']) {
    const paths = [baseline, prototype].map(dir => `${dir}/seed-${seed}/${file}`);
    const compressed = paths.map(path => readFileSync(path));
    const bytes = compressed.map(buffer => file.endsWith('.gz') ? gunzipSync(buffer) : buffer);
    comparison[file] = { inputs: paths.map((path,index) => ({ path, sha256: sha(compressed[index]), rawSha256: sha(bytes[index]) })),
      rawBytesEqual: bytes[0].equals(bytes[1]), parsedEqual: isDeepStrictEqual(JSON.parse(bytes[0].toString()), JSON.parse(bytes[1].toString())) };
  }
  const unlinked = rows.filter(row => row.mature && row.directReceipts.length === 0);
  return { seed, sourceRevision: raw.provenance.sourceRevision, endTick: raw.endTick,
    inputs: [{ path: rawPath, sha256: sha(rawBytes) }, { path: contextPath, sha256: sha(contextBytes) }],
    summary: { heavy: rows.length, mature: rows.filter(row => row.mature).length, direct: rows.filter(row => row.mature && row.directReceipts.length > 0).length,
      censored: rows.filter(row => !row.mature).length, unlinked: unlinked.length, unclassified: classification.unclassified.length, unresolved: classification.unresolved.length },
    missingByCommand: Object.fromEntries([...new Set(unlinked.map(row => row.command))].map(command => [command, unlinked.filter(row => row.command === command).length])),
    comparison, unclassified: classification.unclassified, rows };
});
const summary = Object.fromEntries(Object.keys(seeds[0].summary).map(key => [key, seeds.reduce((sum,seed) => sum+seed.summary[key],0)]));
const result = { status: 'collection_only_unverified_replay_not_gate',
  formula: 'classified cameHeavyToLord true; mature answer.tick+12000<=endTick; nondecision because exact own historyId, answer.tick<receipt.tick<=min(endTick,answer.tick+12000)',
  summary, seeds };
writeFileSync('.omo/evidence/tlink-23d-three-seed-provisional-links.json', JSON.stringify(result,null,2)+'\n', {flag:'wx'});
console.log(JSON.stringify({ summary, seeds: seeds.map(seed => ({seed:seed.seed,summary:seed.summary,missingByCommand:seed.missingByCommand,comparison:seed.comparison}))},null,2));
