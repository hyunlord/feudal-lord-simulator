import { readFileSync, writeFileSync } from 'node:fs';
import { resolve, join } from 'node:path';
import { createHash } from 'node:crypto';
import assert from 'node:assert/strict';
const [replayArgument, rawArgument, outputArgument, ...extra] = process.argv.slice(2);
assert.ok(replayArgument && rawArgument && outputArgument && extra.length === 0, 'Usage: node whole-heavy-answer-trace.mjs REPLAY_DIR RAW_DIR NEW_OUTPUT_JSON');
const replay = resolve(replayArgument), rawDirectory = resolve(rawArgument);
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const load = path => { const bytes = readFileSync(path); return { value: JSON.parse(bytes), sha256: sha(bytes) }; };
const inputs = [], answers = [];
for (const seed of [1, 2, 3]) {
  const directory = join(replay, `seed-${seed}`), manifest = load(join(directory, 'manifest.json'));
  const validity = load(join(directory, 'validity.json')), classification = load(join(directory, 'answer-classification.json'));
  const raw = load(join(rawDirectory, `seed-${seed}.json`)), run = raw.value;
  assert.equal(manifest.value.valid, true); assert.equal(manifest.value.browserEligible, true);
  assert.equal(validity.value.manifestSha256, manifest.sha256);
  assert.equal(manifest.value.raw.sha256, raw.sha256);
  assert.equal(run.provenance.sourceRevision, '2485af40046793f1856829fa1161dc4431942aa7');
  assert.equal(run.provenance.dirtyPaths, ''); assert.equal(run.endTick, 500000);
  assert.equal(run.observation.firstTick, 0); assert.equal(run.observation.lastTick, 500000);
  assert.equal(run.observation.maxGap, 1); assert.equal(run.observation.reversals, 0);
  const history = new Map(run.history.map(row => [row.id, row])), roots = new Map(run.decisions.map(row => [row.id, row]));
  assert.equal(history.size, run.history.length); assert.equal(roots.size, run.decisions.length);
  const byCause = new Map();
  for (const row of run.history.filter(row => row.kind !== 'decision')) {
    for (const id of new Set((row.because ?? []).map(cause => cause.decisionId))) {
      if (!byCause.has(id)) byCause.set(id, []);
      byCause.get(id).push(row);
    }
  }
  const receipts = (id, tick) => (byCause.get(id) ?? []).filter(row => row.tick > tick && row.tick <= Math.min(tick + 12000, run.endTick))
    .sort((a, b) => a.tick - b.tick || a.id.localeCompare(b.id)).map(row => ({ id: row.id, tick: row.tick }));
  const chosen = classification.value.rows.filter(row => row.status === 'classified' && row.cameHeavyToLord === true);
  assert.equal(new Set(chosen.map(row => row.historyId)).size, chosen.length);
  for (const row of chosen) {
    const decision = history.get(row.historyId); assert.equal(decision?.kind, 'decision'); assert.equal(decision.tick, row.tick);
    assert.ok(row.tick >= 0 && row.tick < run.endTick);
    const ownRoot = roots.get(row.historyId);
    const candidates = ownRoot ? [] : run.decisions.filter(root => root.tick <= row.tick && row.tick <= (root.lastTick ?? root.tick)
      && (root.source === row.source || (root.also ?? []).includes(row.source)));
    answers.push({ seed, ordinal: row.ordinal, historyId: row.historyId, tick: row.tick, year: 1300 + Math.floor(row.tick / 4000),
      command: row.command, kind: row.kind, source: row.source, mature: row.tick + 12000 <= run.endTick,
      ownRootId: ownRoot?.id ?? null, directReceipts: receipts(row.historyId, row.tick),
      inferredRootCandidates: candidates.map(root => ({ id: root.id, tick: root.tick, lastTick: root.lastTick ?? root.tick,
        source: root.source, match: root.source === row.source ? 'source' : 'also', laterRootReceipts: receipts(root.id, row.tick) })),
      inferredRootMembershipVerified: false });
  }
  inputs.push({ seed, rawSha256: raw.sha256, replayManifestSha256: manifest.sha256, validitySha256: validity.sha256,
    classificationSha256: classification.sha256, sourceRevision: run.provenance.sourceRevision });
}
function summarize(rows) {
  const result = { answers: rows.length };
  for (const [label, subset] of [['mature', rows.filter(row => row.mature)], ['censored', rows.filter(row => !row.mature)]]) {
    result[label] = { answers: subset.length, direct: subset.filter(row => row.directReceipts.length).length,
      ownRoot: subset.filter(row => row.ownRootId !== null).length,
      ownRootDirect: subset.filter(row => row.ownRootId !== null && row.directReceipts.length).length,
      nonRoot: subset.filter(row => row.ownRootId === null).length,
      uniqueInferredRootWithLaterReceipts: subset.filter(row => row.inferredRootCandidates.length === 1 && row.inferredRootCandidates[0].laterRootReceipts.length).length };
  }
  return result;
}
assert.equal(answers.length, 836);
const report = { sourceRevision: inputs[0].sourceRevision, formula: {
  selection: 'classification status=classified and cameHeavyToLord=true; each answer own history ID',
  direct: 'non-decision history record because names exact answer historyId; answerTick < receiptTick <= min(answerTick+12000,500000)',
  mature: 'answerTick+12000 <= 500000',
  inferredCandidate: 'non-root answer only; root.tick <= answer.tick <= root.lastTick (or root.tick); exact source or also match; not canonical membership',
}, limitations: ['No own-ID receipt does not prove no gameplay effect.', 'Inferred root receipts do not prove answer-specific causality.',
  'Censored answers have incomplete follow-up.', 'Pinned trace taxonomy excludes two unclassified proclamation commands.',
  'This offline join does not verify main-cause semantics or rendered visibility.'], inputs,
  pooled: summarize(answers), perSeed: [1, 2, 3].map(seed => ({ seed, ...summarize(answers.filter(row => row.seed === seed)) })), answers };
writeFileSync(resolve(outputArgument), `${JSON.stringify(report)}\n`, { flag: 'wx' });
console.log(JSON.stringify(report.pooled));
