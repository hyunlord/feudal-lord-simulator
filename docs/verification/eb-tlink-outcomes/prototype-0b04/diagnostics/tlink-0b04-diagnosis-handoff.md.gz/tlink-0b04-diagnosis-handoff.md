# EB-TLINK 0b04 중간 진단 인계 — 공식 판정 전

측정 소스는 `0b04cd0becc4d73059fbfcf372395c8672d1a381`, 실행은 `engineB-tlink-prototype125-0b04cd0`이다. 125년 × seed 1/2/3 **수집 산출물의 잠정 집계**이며 공식 replay/scorer 인수 결과가 아니다. 부모 확인 시점에 seed 1·3 replay 완료, seed 2 진행 중이다. 이 문서 작성에서는 원격 상태를 다시 조회하지 않았다. 정식 도구 검증 후 부모가 잠정 표시를 교체해야 한다.

## 현재 수치와 해석

| 범위 | 성숙한 실제 heavy 답변 | 미래 own-ID receipt 있음 | 미연결 |
|---|---:|---:|---:|
| seed 1 | 238 | 52 | 186 |
| seed 2 | 275 | 70 | 205 |
| seed 3 | 303 | 82 | 221 |
| 합계 | 816 | 204 (25%) | 612 |
| 기존 baseline | 816 | 292 (35.7843%) | 524 |

실제 heavy 답변은 836건, 미성숙 20건이다. unclassified 2건은 원래 지표 밖에 명시적으로 남는다. 차이는 −88건/−10.7843%p이나 이를 전부 신규 결함이나 전부 허위 연결 제거로 단정하지 않는다. 잠정 집계는 기존 조건 그대로 `answer.tick < receipt.tick <= min(endTick, answer.tick+12000)`인 비결정 기록의 because에 **정확한 own answer ID**가 있는지를 센다. 성숙은 `answer.tick+12000<=500000`이다. scorer·분모를 수정하지 않았고 같은 tick의 종결 영수증을 미래 성과로 올리지 않았다. receipt 부재를 conditional-unmet으로 만들지 않았다.

## 사라진 연결과 실제 남은 연결 부재

루트 병합의 estate 공통 target이나 이미 덮어쓴 설정의 과거 소유자에게 미래 결과를 붙이는 것은 own-answer 인과 증거가 아니다. 0b04는 선택한 명령의 target·시점별 설정 소유권·정확한 faction memory 기여를 요구한다(`src/engine/decisionTraceAnswers.ts`, `decisionTraceAnswerLedger.ts`). 그러나 누락 612건의 원인을 전부 분류한 것은 아니다.

구체 비교는 `tlink-seed1-provisional-links.json`에 보존했다. seed 1 `h-003827`(audit tolerate, 58345)은 baseline에서 70320의 estate 공통 `audit` 결과를 받았고, `h-006655`(charter 거절, 102025)는 110320의 같은 estate audit 결과를 받았다. 현재는 두 답변의 실제 같은-tick 종결 기록만 있고 미래 own-ID 링크는 없다. 이는 감사/청원 답변이 같은 영지라는 이유만으로 다음 감사를 일으켰다고 볼 수 없다는 제한을 드러낸다. raw에서 `h-002653`(005:c, 40015) 바로 뒤 같은 tick의 `h-002654`는 dues를 1100으로 정한다. `h-009583`(130:c, 148045) 뒤 `h-009588`(148123)은 audit mode를 accounts로 정한다. `h-003827` 뒤 `h-004074`(62323)은 다음 audit를 punish한다. `h-007173`의 실제 because에는 다른 9개 답변 ID가 있고 `h-006655`는 없다. 이런 후속 설정/답변과 원래 root 별칭 경로(`decisionTrace.ts:380–390`, `decisionTraceAnswers.ts:10–17`)를 구분해야 한다. 위 사례는 raw를 직접 확인한 예시이며 모든 손실의 자동 인과 분류가 아니다; 후속 명령의 존재만으로 임의의 receipt 소유권을 증명하지 않는다.

성숙 미연결의 command별 합은 estate petition 433, audit 94, registry 69, petition response 15, will change 1이다. 이 중에는 실제 설정·관계·정산 변화가 있었어도 미래 기록에 연결하지 못한 경우와 즉시 종결만 확인되는 경우가 함께 있다. 모든 estate/audit에 같은 영지의 후속 수입·감사를 일괄 연결하지 않는다.

## 관계 포화 0의 source-derived 증거와 한계

- Charter: seed 1 전체 시즌 청원 449개, 실제 lord context 138개, oversight 변경 15개를 순방향 fold했다. 최초 관계 0부터 시작해 8개 잔존 시즌 snapshot와 최종값을 교차 확인했다. 거절 71건 중 상인 관계 −100→−100은 19건이며, 그중 성숙 17건/미성숙 2건이다. 19개 ID·ordinal·tick·성숙 여부와 미래 receipt 0을 별도 잠정 링크 JSON과 대조했다.
- Audit: 초기 candidate seed 계산과 완전한 audit 112개 순서를 따라 12명 최종 loyalty를 대조했다. 명시적 tolerate 33건 중 loyalty 증가 6/증가 0인 27건이다. 성숙 미연결 32건과 정확 ID로 교차하면 증가 0은 **26건**이다.
- 독립검토: scope_review, 차단 결함 없음(기록 시점 2026-10-10, 부모가 전달한 실제 검토 메시지 기준). 독립 검토 전문이 이 묶음에 별도 파일로 보존된 것은 아니므로 서명된 공식 실행 검증으로 취급하지 않는다.
- Charter 거절의 handler는 income/tenants/kept 0, neglect false, merchants −8이며 권리·소유권을 변경하지 않는다(`stewardship.ts:175–186,471–499`). 다만 refused/decidedBy lord로 종결되어 open/lapse 경로에서 빠지고 `registry.ts:133`의 lordDecided 입력에 포함된다. Tolerate도 pending→tolerated로 종결되어 재답변·자동 lapse 대상에서 빠진다(`stewardship.ts:384–389,544–568`). 따라서 **관계/충성도 수치 변화 0**만 증명했으며 전체 명령 무효나 미래 효과 불가능을 증명하지 않았다.
- 성숙 17+26=43건은 238건에서 80% 미달을 강제할 49건에도 못 미친다. 전체 목표의 구조적 불가능이나 분모 제외 근거가 아니다. final clamp에서 과거값을 역추정하지 않았고 counterfactual 실행도 하지 않았다.

선택적 trace-chain 개선은 별도 aux 작업에서 진행 중이며 0b04 코드·측정·판정에 포함하지 않는다. 개선이 기존 실제 결과에 어떤 기여를 입증할 수 있는지 별도 검토해야 하며 연결 수 증가를 선결론으로 두지 않는다.

## 재현과 보존

아래는 **원본이 아닌 별도 재현 checkout**의 repo root에서 수행하는 offline 명령이다. 스크립트의 고정 상대 경로 구조로 해시가 맞는 원본을 배치해야 한다. 첫 명령은 출력이 존재하면 wx로 거절하고, 나머지는 재현 checkout 내 출력만 갱신한다. engine tick·새 게임·원격 작업을 시작하지 않는다.

```sh
node --import tsx .omo/evidence/tlink-three-seed-provisional-links.ts
node --import tsx .omo/evidence/tlink-seed1-provisional-links.ts
node --import tsx .omo/evidence/tlink-audit-loyalty-reconstruction.mjs .omo/evidence/tlink-seed1-provisional-links.json
python3 .omo/evidence/tlink-charter-fold-feasibility.py
```

3-seed 집계는 baseline/prototype 각 seed의 collect-parity, collect-rule-state, original-final-state도 읽는다. 정확한 입력 목록과 압축/비압축 SHA는 집계 JSON의 inputs/comparison에 있다. 수집값 비교가 맞더라도 공식 replay·terminal·전체 게임 hash 인수를 대신하지 않는다. TS 집계는 `scripts/engineBOutcomeEvidence.ts`를 가져오므로 재현 시 0b04 소스와 해당 모듈을 고정해야 한다. audit fold는 git의 0b04 소스 byte 일치를 검사하며 charter fold는 preflight source/tool hash를 검사한다.

compact archive 제안: 아래 분석 scripts/JSON/MD만 gzip으로 보존하고, 별도 provenance에 원본 raw/context/finalstate 경로·크기·SHA와 상대 논리 경로를 기입한다. 대형 raw·context·finalstate를 재복사하거나 3MB 한도 예외를 만들지 않는다. gzip 원본 SHA와 압축 SHA를 함께 SHA256SUMS에 기록한다. 현재 일부 JSON에 작성 머신의 절대 경로가 있으며 script는 특정 run의 상대 경로를 고정한다. 원본을 고쳐 해시를 바꾸지 말고 보존용 manifest의 logicalRoot→사용자 지정 artifactRoot 매핑과 재현 staging 절차로 해소한다. 휴대 가능한 CLI가 이미 구현되었다고 주장하지 않는다. 공식 도구 결과는 나중에 별도 파일로 추가하고 이 잠정 결과는 덮어쓰지 않는다.

| 파일 (`.omo/evidence/`) | bytes | SHA256 |
|---|---:|---|
| `tlink-three-seed-provisional-links.ts` | 3986 | `4c66702780279f4883292b90cc960ec37ffd17ae4312ce86dec22310b9bf1a80` |
| `tlink-three-seed-provisional-links.json` | 504942 | `fbb9bd15411227c84ecb104a4758af3fd04a191bf162deba7cb447fc1ff72fdf` |
| `tlink-seed1-provisional-links.ts` | 3003 | `a6e04a82e31ddce04054d43530dfa54cf84393b9c444e3c545ddd90c4eeb0cfb` |
| `tlink-seed1-provisional-links.json` | 150240 | `8911b31d08d148d29f3e6bde5324c20251412ee1da58632042e324317d2bead2` |
| `tlink-audit-loyalty-reconstruction.mjs` | 7984 | `dade41f4a44ce256ba6bf6ae4f59be421471da91466d3b2ca21d82b4abbfbcff` |
| `tlink-audit-loyalty-reconstruction.json` | 56801 | `cd460716af81f22572d7c27140c32306c01d9a7c38ddfb2472f509495aff2a74` |
| `tlink-charter-fold-feasibility.py` | 6524 | `869d958a0be50d1fd84f3341044965396f4e7fb9ea6fdc85bbcaebeb06c2b8ef` |
| `tlink-charter-fold-feasibility.json` | 19194 | `827d420af4dbf3de9f3e7ed001f9be460ef782b7b87ee0832d98e47a6c6b5ba0` |
| `tlink-charter-fold-feasibility.md` | 4800 | `c91bd505ffdeac7fa4ab4a68b8c2f532c228c6267dfb6485261a0e6454bf42e7` |

Baseline 공식 보존 파일: `docs/verification/eb-tlink-outcomes/baseline-score.json.gz`, SHA256 `339bc8e2861f50a61abb8ee7c2471eba4c3ef3b63ee0072947c9524b932e6ed8`.

위 9개 파일을 각각 gzip한 예상 합계는 54,429 bytes이며 3MB 미만이다(메모리 내 압축 크기 확인, archive 아직 미작성). 이 문서에는 raw 본문·전체 state·이미지를 넣지 않았다.
