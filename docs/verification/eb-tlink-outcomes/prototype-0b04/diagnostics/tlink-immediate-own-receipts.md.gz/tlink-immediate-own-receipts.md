# 0b04 unexplained 답의 실제 즉시 처리 기록

정식 scorer/residual 입력의 SHA·config·manifest/raw 핀·context gzip 핀을 검증한 오프라인 목록이다. 기존 분류나 점수는 변경하지 않는다. 재현: `node .omo/evidence/tlink-immediate-own-receipts.mjs`.

179 unexplained 중101답에 정확한 자기 ID because를 가진 같은 tick 비결정 기록이 있다. 94는 `stewardship.audit_answered`, 나머지7은 `stewardship.oversight`3, `stewardship.audit_mode`3, `estate.possession_enforced`1이다. 나머지78답에는 해당 기록이 없다. JSON은179답 전체의 기록ID/template/params/because, 명령·답변 이력, 원본 소스 핀을 보존한다.

## 판정 후보와 금지할 확대

- 감사 용인94답: 명령의 auditId와 자기 결정 이력 subjectId가94/94 정확히 일치한다. 같은 tick actual domain record가 자기 답을 decision_effect로 연결한다. `history.ts:1115-1116`은 pending→settled 실제 감사 전이만 이 기록을 만든다. 따라서 **정확한 답의 감사 처리 관측** 후보는 가능하다. 그러나 해당 기록에는 auditId/estateId가 없고 retained contexts에도 감사 before/after가 없다. stewardId/name을 estateId로 추정하거나 충성도 변화/미래 정산 효과를 증명했다고 하면 안 된다.
- 감독/감사 방식6답: 실제 상태 변경에서 생성되는 기존 기록과 자기 답의 exact because가 있다(`history.ts:1130-1133`). oversight에는 estateID가 있지만 audit_mode는 house만 있으므로 별도 실제 바인딩 검증 없이 영지 ID를 추정하지 않는다.
- 집행1답: seed2 h-003603→h-003602, attempt2/succeeded0. **해당 집행 시도의 실패 관측** 후보이며3년 전체 조건 미충족이나 미래 결과가 아니다.
- 모든101건은 같은 tick이다. 미래 직접 분자204/816=25%에 더할 수 없다. 처리 관측과 의미 있는 비영(非零) 효과는 다르다.

## commands[] 보류

47답:038defer10,201c10,204c6,209d8,211c12,005c1. 승인 기대표와 실제0b04 `src/content/registry/v4Entries.generated.ts`의 사건/선택/commands를 대조했다. JSON 각 행에 revision·정본파일SHA·정확한selector를 보존한다. 이전 잠정46 목록은005c1을 빠뜨렸으며 이 목록이 완전한179대상 결과다. 기존 설정 유지가 실제 처리 선택이라는 점과 이후 수입을 그 답이 발생시켰다는 주장은 구분한다.

## 연결/출처 한계

`linkImmediateAnswerReceipts`는 해당 명령 전에 없던 실제 domain record에만 own answer ID를 첨부한다(`decisionTraceAnswerReceipts.ts:62-75`). 이 목록은 그 기록을 다시 만들지 않는다. 답 당시 context와 최종 archive 이력은 ID/ordinal/tick/전체필드가 일치해야 하며, 나중에 채워지는 decision.actual만 비교에서 별도로 제외했다. 생성기·동적판정기·엔진·기대표에는 수정이 없다.
