"""Read-only archive joins; no engine execution or score mutation."""
from pathlib import Path
import gzip
import hashlib
import json
import subprocess

ROOT = Path(__file__).resolve().parents[2]
RUN = 'engineB-tlink-audit125-23d1226'
SOURCE = '23d12264289538de5f6ef3ef3f36aa9257b10aba'
BASE = ROOT / '.remote-runs' / RUN / 'eb-tlink-audit-final'
OUTPUT = Path(__file__).with_suffix('.json')


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(ok: bool, reason: str) -> None:
    if not ok:
        raise ValueError(reason)


def main() -> None:
    require(not OUTPUT.exists(), 'Refuse overwriting proof')
    inputs = []

    def read(path: Path) -> bytes:
        data = path.read_bytes()
        inputs.append({'path': str(path.relative_to(ROOT)), 'sha256': sha(data), 'bytes': len(data)})
        return data

    residual_bytes = read(ROOT / '.omo/evidence/final-23d-residuals.json')
    score_path = ROOT / '.omo/evidence/final-23d-score.json'
    score_bytes = read(score_path)
    residual = json.loads(residual_bytes)
    score = json.loads(score_bytes)
    require(residual['originalScoreSha256'] == sha(score_bytes), 'Residual-score binding')
    require(residual['originalPrimaryMetric'] == score['legacyDirectRatio'] and residual['originalScoreUnmodified'] is True, 'Metric mismatch')
    rows = []
    source_pins = {}
    for seed in (1, 2, 3):
        directory = BASE / f'seed-{seed}'
        manifest_bytes = read(directory / 'manifest.json')
        manifest = json.loads(manifest_bytes)
        require(manifest['sourceRevision'] == SOURCE and manifest['seed'] == seed and manifest['years'] == 125, 'Source/cohort mismatch')
        require(manifest['valid'] is True and manifest['replayVerified'] is True, 'Replay incomplete')
        validity = json.loads(read(directory / 'validity.json'))
        require(validity['valid'] is True and validity['manifestSha256'] == sha(manifest_bytes), 'Validity mismatch')
        raw_bytes = read(BASE / f'seed-{seed}.json')
        context_bytes = read(directory / 'original-contexts.json.gz')
        raw = json.loads(raw_bytes)
        contexts = json.loads(gzip.decompress(context_bytes))
        require(manifest['raw']['sha256'] == sha(raw_bytes) and manifest['contextSha256'] == sha(context_bytes), 'Raw/context mismatch')
        require(raw['provenance']['sourceRevision'] == SOURCE, 'Raw source mismatch')
        final_bytes = gzip.decompress(read(directory / 'original-final-state.json.gz'))
        replay_bytes = gzip.decompress(read(directory / 'final-state.json.gz'))
        comparison = manifest['finalComparison']
        require(final_bytes == replay_bytes and sha(final_bytes) == comparison['expectedSha256'] == comparison['actualSha256'] == manifest['final']['stateSha'], 'Original/replay final state pin mismatch')
        require(manifest['final']['hit'] is True and manifest['final']['tick'] == 500000, 'Final incomplete')
        final = json.loads(final_bytes)
        require(final['seed'] == seed and final['tick'] == 500000, 'Final cohort mismatch')
        for path in ('src/engine/stewardship.ts', 'src/engine/decisionTraceAnswerReceipts.ts', 'src/engine/history.ts'):
            pin = next(p['sha256'] for p in manifest['sourceFiles'] if p['path'] == path)
            require(sha(subprocess.check_output(['git', 'show', f'{SOURCE}:{path}'], cwd=ROOT)) == pin, 'Source blob pin mismatch')
            source_pins[path] = pin
        selected = [r for r in residual['residuals'] if r['seed'] == seed and r['command'] == 'answer_audit' and r['category'] == 'unexplained']
        seen_answers, seen_audits, seen_receipts = set(), set(), set()
        for answer in selected:
            provenance = answer['provenance']
            require(provenance['sourceRevision'] == SOURCE and provenance['rawSha256'] == sha(raw_bytes) and provenance['contextSha256'] == sha(context_bytes) and provenance['replayManifestSha256'] == sha(manifest_bytes), 'Residual input pin mismatch')
            matches = [c for c in contexts if c.get('history') and c['history']['id'] == answer['historyId']]
            require(len(matches) == 1, 'Ambiguous context join')
            context = matches[0]
            command, history = context['command'], context['history']
            require(context['ordinal'] == answer['ordinal'] and context['tick'] == history['tick'] == answer['tick'], 'Answer timing mismatch')
            require(command['type'] == 'answer_audit' and command['choice'] == 'tolerate' and context['stateChanged'] is True, 'Not successful tolerate command')
            require(history['params']['command'] == command['type'] and history['params']['subjectId'] == command['auditId'] and history['params']['chosen'] == 'tolerate', 'Command subject mismatch')
            audits = [a for a in final['stewardship']['audits'] if a['id'] == command['auditId']]
            require(len(audits) == 1, 'Ambiguous retained audit')
            audit = audits[0]
            require(audit['status'] == 'tolerated' and audit['tick'] <= answer['tick'] <= audit['deadline'], 'Audit status/window mismatch')
            receipts = [r for r in raw['history'] if r['kind'] != 'decision' and r['tick'] == answer['tick'] and any(c['decisionId'] == answer['historyId'] for c in r.get('because', []))]
            require(len(receipts) == 1, 'Ambiguous own-answer receipt')
            receipt = receipts[0]
            require(receipt['template'] == 'stewardship.audit_answered' and receipt['params']['stewardId'] == audit['stewardId'] and receipt['params']['choice'] == 'tolerated' and receipt['params']['recovered'] == 0, 'Receipt target/status mismatch')
            require(answer['historyId'] not in seen_answers and audit['id'] not in seen_audits and receipt['id'] not in seen_receipts, 'Duplicate settlement')
            seen_answers.add(answer['historyId']); seen_audits.add(audit['id']); seen_receipts.add(receipt['id'])
            own_root = context['ownRoot']
            if own_root is not None:
                require(own_root['id'] == answer['historyId'] and f"estate:{audit['estateId']}" in own_root['targets'], 'Own-root estate mismatch')
            require(all(value is None for value in context['context'].values()), 'New domain context requires review')
            rows.append({'seed': seed, 'historyId': answer['historyId'], 'ordinal': answer['ordinal'], 'tick': answer['tick'], 'command': command, 'audit': audit, 'receipt': receipt, 'estateId': audit['estateId'], 'targetBasis': 'own_root_and_retained_audit' if own_root else 'exact_retained_audit_id', 'stateChanged': True, 'auditBeforeAfterCaptured': False, 'loyaltyDeltaObserved': None, 'futureMetricCreditAdded': False})
    require(len(rows) == 94 and sum(r['targetBasis'] == 'own_root_and_retained_audit' for r in rows) == 43, 'Unexpected population')
    require(score_path.read_bytes() == score_bytes, 'Score changed during observation')
    result = {'schemaVersion': 1, 'run': RUN, 'sourceRevision': SOURCE, 'helperSha256': sha(Path(__file__).read_bytes()), 'inputs': inputs, 'sourcePins': source_pins, 'counts': {'exactSettlements': 94, 'ownRootAndFinalAudit': 43, 'finalAuditOnly': 51, 'directAuditBeforeAfter': 0, 'directLoyaltyDeltaProof': 0}, 'originalScoreSha256': sha(score_bytes), 'originalPrimaryMetric': score['legacyDirectRatio'], 'scoreBytesUnchanged': True, 'rows': rows, 'limits': ['Same-tick settlement/status proof only; original future-only numerator unchanged.', 'Zero loyalty-delta proof means unobserved, NOT zero actual loyalty change.', 'Final retained audit supplies exact estate/steward identity; no target inference from names or merged roots.', 'No engine execution, new simulation, or blanket immediate-success reclassification.']}
    with OUTPUT.open('x') as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    print(json.dumps({'path': str(OUTPUT), 'sha256': sha(OUTPUT.read_bytes()), 'counts': result['counts'], 'scoreBytesUnchanged': True}))


if __name__ == '__main__':
    main()
