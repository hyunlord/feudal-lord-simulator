import { readFileSync, writeFileSync } from 'node:fs';
import { gunzipSync } from 'node:zlib';
import { createHash } from 'node:crypto';
import { execFileSync } from 'node:child_process';
import assert from 'node:assert/strict';
import { resolve, dirname } from 'node:path';
const revision = '0b04cd0becc4d73059fbfcf372395c8672d1a381';
const base = '.remote-runs/engineB-tlink-prototype125-0b04cd0/eb-tlink-prototype';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const inputs = [], sourcePins = [], archiveChecks = [];
const fileHash = path => sha(readFileSync(path));
function read(path) {
  const bytes = readFileSync(path); inputs.push({ path, sha256: sha(bytes) });
  return JSON.parse((path.endsWith('.gz') ? gunzipSync(bytes) : bytes).toString());
}
function source(path) {
  const bytes = execFileSync('git', ['show', `${revision}:${path}`]);
  sourcePins.push({ path, revision, sha256: sha(bytes), currentBytesEqual: bytes.equals(readFileSync(path)) });
  return bytes.toString();
}
const config = source('src/content/factionConfig.ts');
const starts = Object.fromEntries([...config.matchAll(/id: "([^"]+)", kind: "[^"]+", startRelation: (-?\d+)/g)].map(row => [row[1], Number(row[2])]));
const entriesText = source('src/content/registry/v4Entries.generated.ts');
const entries = JSON.parse(entriesText.match(/^export const V4_LIVE_ENTRIES: unknown = (.*);$/m)[1]);
for (const path of ['src/content/registry/registryHoldConfig.ts', 'src/content/registry/v4Copy.generated.ts',
  'src/content/registry/v4Holds.generated.ts', 'src/engine/registryV4.ts', 'src/engine/registry.ts',
  'src/engine/history.ts', 'src/engine/factions.ts', 'src/engine/factionActs.ts',
  'src/content/factionActConfig.ts', 'src/engine/estateSuits.ts', 'src/engine/marriage.ts',
  'src/engine/memoryFold.ts', 'src/engine/decisionTraceAnswers.ts', 'scripts/engineBOutcomeEvidence.ts']) source(path);
const configPath = '.omo/evidence/prototype-0b04-config.json';
const scorePath = '.omo/evidence/prototype-0b04-score.json';
const residualPath = '.omo/evidence/prototype-0b04-residuals.json';
const auditConfig = read(configPath), score = read(scorePath), residuals = read(residualPath);
assert.equal(fileHash(configPath), score.configSha256);
assert.equal(fileHash(configPath), residuals.provenance.configSha256);
assert.equal(fileHash(scorePath), residuals.originalScoreSha256);
assert.equal(auditConfig.contractSha256, score.contractSha256);
assert.equal(auditConfig.contractSha256, residuals.provenance.contractSha256);
assert.equal(fileHash(resolve(dirname(configPath), auditConfig.contractFile)), auditConfig.contractSha256);
assert.equal(resolve(dirname(configPath), auditConfig.rawDirectory), resolve(base));
assert.equal(resolve(dirname(configPath), auditConfig.replayDirectory), resolve(base));
assert.deepEqual(auditConfig.seeds, [1, 2, 3]); assert.equal(auditConfig.horizonTicks, 12000);
const chain = { configSha256: fileHash(configPath), scoreSha256: fileHash(scorePath), residualSha256: fileHash(residualPath),
  contractSha256: auditConfig.contractSha256, verified: true };

const rows = [], validations = [];
for (const seed of [1, 2, 3]) {
  const raw = read(`${base}/seed-${seed}.json`);
  const contexts = read(`${base}/seed-${seed}/original-contexts.json.gz`);
  const state = read(`${base}/seed-${seed}/original-final-state.json.gz`);
  const folder = `${base}/seed-${seed}`;
  const manifest = read(`${folder}/manifest.json`), validity = read(`${folder}/validity.json`);
  const pin = auditConfig.replayPins.find(row => row.seed === seed); assert.ok(pin);
  const manifestSha = fileHash(`${folder}/manifest.json`), rawSha = fileHash(`${base}/seed-${seed}.json`);
  assert.equal(manifestSha, pin.manifestSha256); assert.equal(rawSha, pin.rawSha256);
  assert.equal(manifest.raw.sha256, rawSha); assert.equal(validity.manifestSha256, manifestSha);
  assert.equal(manifest.sourceRevision, revision); assert.equal(manifest.seed, seed);
  assert.equal(manifest.replayFormat, auditConfig.replayFormat);
  assert.equal(manifest.valid, true); assert.equal(manifest.replayVerified, true); assert.equal(validity.valid, true);
  assert.equal(manifest.source.status, ''); assert.equal(manifest.source.lock, manifest.source.expectedLock);
  assert.equal(manifest.source.revision, revision); assert.equal(manifest.raw.provenance.sourceRevision, revision);
  assert.equal(fileHash(`${folder}/original-contexts.json.gz`), manifest.contextSha256);
  assert.equal(fileHash(`${folder}/answer-contexts.json.gz`), manifest.contextSha256);
  const finalRawSha = sha(gunzipSync(readFileSync(`${folder}/original-final-state.json.gz`)));
  assert.equal(finalRawSha, manifest.final.stateSha);
  assert.equal(finalRawSha, manifest.finalComparison.expectedSha256);
  assert.equal(finalRawSha, manifest.finalComparison.actualSha256);
  assert.equal(sha(gunzipSync(readFileSync(`${folder}/final-state.json.gz`))), finalRawSha);
  for (const provenance of [score.inputs.find(row => row.seed === seed), residuals.provenance.inputs.find(row => row.seed === seed)]) {
    assert.ok(provenance); assert.equal(provenance.rawSha256, rawSha);
    assert.equal(provenance.replayManifestSha256, manifestSha);
    assert.equal(provenance.validitySha256, fileHash(`${folder}/validity.json`));
    assert.equal(provenance.classificationSha256, fileHash(`${folder}/answer-classification.json`));
    assert.equal(provenance.sourceRevision, revision);
  }
  for (const pin of sourcePins) {
    const published = pin.path.startsWith('scripts/') ? manifest.toolHashes[pin.path.split('/').at(-1)]
      : manifest.sourceFiles.find(row => row.path === pin.path)?.sha256;
    assert.equal(published, pin.sha256, pin.path);
  }
  archiveChecks.push({ seed, manifestSha256: manifestSha, rawSha256: rawSha, contextSha256: manifest.contextSha256,
    uncompressedFinalStateSha256: finalRawSha, valid: validity.valid, replayVerified: manifest.replayVerified });
  assert.equal(raw.provenance.sourceRevision, revision);
  const deltas = new Map();
  for (const faction of state.factions.factions) {
    let relation = starts[faction.id]; assert.ok(Number.isFinite(relation));
    for (const memory of faction.memory) {
      assert.ok(!memory.reason.startsWith('folded:'));
      const before = relation; relation = Math.max(-100, Math.min(100, relation + memory.delta));
      const key = `${faction.id}:${memory.recordId}`; assert.ok(!deltas.has(key), `duplicate memory ${key}`);
      deltas.set(key, { before, after: relation, actual: relation - before, memory });
    }
    assert.equal(relation, faction.relation);
    validations.push({ seed, faction: faction.id, reconstructed: relation, stored: faction.relation, equal: true });
  }
  for (const context of contexts) {
    const occurrence = context.context?.registryAfter;
    if (context.command.type !== 'answer_registry_offer' || occurrence?.status !== 'answered' || !occurrence.hold) continue;
    const entry = entries.find(row => row.id === occurrence.entryId);
    const choice = entry?.choices.find(row => row.id === occurrence.choiceId);
    assert.deepEqual(choice?.commands, []);
    const own = state.trace.answers.find(row => row.id === context.history?.id); assert.ok(own);
    const hold = occurrence.hold;
    const residual = residuals.residuals.find(row => row.seed === seed && row.historyId === own.id);
    const future = raw.history.filter(row => row.tick > own.tick && row.tick <= Math.min(raw.endTick, own.tick + 12000)
      && row.because?.some(cause => cause.decisionId === own.id));
    const baseRow = { seed, historyId: own.id, tick: own.tick, entryId: entry.id, choiceId: choice.id,
      commands: choice.commands, occurrenceId: occurrence.id, bound: occurrence.bound, hold,
      mature: own.tick + 12000 <= raw.endTick,
      officialResidual: residual ? { category: residual.category, reason: residual.reason } : null,
      futureOwnRecords: future.map(row => ({ id: row.id, tick: row.tick, template: row.template, params: row.params })),
      scope: 'All commands-empty successful lord holds, not the official unexplained subset.' };
    if (hold.faction) {
      const evidence = own.memoryEvidence.filter(row => row.reason === own.source && row.factionId === hold.faction);
      assert.equal(evidence.length, 1);
      const delta = deltas.get(`${hold.faction}:${evidence[0].recordId}`); assert.ok(delta);
      assert.equal(delta.memory.tick, own.tick); assert.equal(delta.memory.reason, own.source);
      assert.equal(evidence[0].tick, own.tick); assert.equal(evidence[0].delta, delta.memory.delta);
      assert.equal(own.source, `registry:${entry.id}:${choice.id}`); assert.equal(own.tick, context.tick);
      const acts = raw.history.filter(row => row.template === 'faction.act' && row.params?.faction === hold.faction
        && row.tick > own.tick && row.tick <= Math.min(raw.endTick, own.tick + 12000));
      rows.push({ ...baseRow, canonicalCost: { kind: 'relation', nominal: -2, source: 'registryV4.ts:167-174,184-195' },
        actualDelta: delta.actual, actualDeltaProof: 'Source-derived ordered unfurled memory reconstruction; all nine final faction values agree per seed.',
        before: delta.before, after: delta.after, memoryEvidence: evidence[0],
        negativeActs: acts.filter(row => row.params.relation < 0).map(row => ({ id: row.id, tick: row.tick, because: row.because })),
        observedPositiveActs: acts.filter(row => row.params.relation > 0).map(row => row.id),
        limit: 'A nonzero immediate relation delta does not prove a future act. Same-direction acts need actual threshold/cadence state; positive acts cannot be credited to this negative cost.' });
    } else {
      assert.ok(hold.claimId);
      const finalClaim = state.estates.claims.find(row => row.id === hold.claimId);
      rows.push({ ...baseRow, canonicalCost: { kind: 'claim', nominal: -5, source: 'registryV4.ts:167-174,184-192' },
        actualDelta: null, actualDeltaProof: 'Not reconstructable from the retained answer context: claim strength before/after absent. hold.weakened is nominal, final strength is not answer-time proof.',
        finalClaim: { id: finalClaim?.id, strength: finalClaim?.strength, status: finalClaim?.status },
        authoredSuitBinding: entry.bindings.suit,
        futureConsumer: entry.id === 'ck_evt_038' ? 'Already enforcing after plaintiff judgment; enforcement reads force/patronSupport/hold, not claim strength.' : 'Filed/evidence stage: suitHearing plaintiff input and later judge consume claim strength.',
        decisiveExperiment: 'Capture real reducer claim strength before/after. At the subsequent actual hearing compare suitHearing with only this proved, unerased reduction restored; separately record score delta and verdict delta. Do not replay a fabricated historical state.' });
    }
  }
}
assert.equal(rows.length, 60);
const factionRows = rows.filter(row => row.canonicalCost.kind === 'relation');
const summary = { allCommandsEmptyHolds: rows.length, claim: rows.length - factionRows.length, relation: factionRows.length,
  relationNonzero: factionRows.filter(row => row.actualDelta !== 0).length, relationNoActualDelta: factionRows.filter(row => row.actualDelta === 0).length,
  claimActualDeltaUnknown: rows.length - factionRows.length, factionFinalChecks: validations.length,
  officialUnexplainedIntersection: rows.filter(row => row.officialResidual?.category === 'unexplained').length,
  preJudgmentClaimCandidates: rows.filter(row => row.canonicalCost.kind === 'claim' && row.entryId !== 'ck_evt_038').length,
  postJudgmentClaimCosts: rows.filter(row => row.entryId === 'ck_evt_038').length,
  relationWithNegativeAct: factionRows.filter(row => row.negativeActs.length).length,
  relationWithNegativeActButMissingOwnLink: factionRows.filter(row => row.negativeActs.some(act => !act.because?.some(cause => cause.decisionId === row.historyId))).length };
const result = { kind: 'read_only_offline_source_derived_not_new_runtime_or_metric', revision,
  currentHead: execFileSync('git', ['rev-parse', 'HEAD']).toString().trim(),
  reproduction: 'node .omo/evidence/tlink-hold-cost-audit.mjs', scriptSha256: sha(readFileSync('.omo/evidence/tlink-hold-cost-audit.mjs')),
  summary, chain, archiveChecks, sourcePins, inputs, validations, rows,
  boundaries: ['60 total holds is not the official 47 unexplained subset.', 'All 43 faction costs are -2 after clamp; no new future outcome is inferred.',
    'Two old 211 hold links to dues_held are not legitimate evidence that hold changed dues.', 'Final trace.acts is retained-window only; act lookup uses the raw collected history instead.',
    'No current official-run score or denominator changed. No engine tick or replay executed.'] };
writeFileSync('.omo/evidence/tlink-hold-cost-audit.json', JSON.stringify(result, null, 2) + '\n');
console.log(JSON.stringify(summary, null, 2));
